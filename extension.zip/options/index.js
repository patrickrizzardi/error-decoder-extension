(() => {
  var __defProp = Object.defineProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, {
        get: all[name],
        enumerable: true,
        configurable: true,
        set: (newValue) => all[name] = () => newValue
      });
  };
  var __esm = (fn, res) => () => (fn && (res = fn(fn = 0)), res);

  // packages/extension/src/shared/storage.ts
  var storage;
  var init_storage = __esm(() => {
    storage = {
      get: async (key) => {
        const result = await chrome.storage.local.get(key);
        return result[key];
      },
      set: async (key, value) => {
        await chrome.storage.local.set({ [key]: value });
      },
      remove: async (key) => {
        await chrome.storage.local.remove(key);
      },
      clear: async () => {
        await chrome.storage.local.clear();
      }
    };
  });

  // packages/extension/src/shared/api.ts
  var exports_api = {};
  __export(exports_api, {
    api: () => api,
    SITE_URL: () => SITE_URL,
    AUTH_URL: () => AUTH_URL,
    API_BASE: () => API_BASE
  });
  var API_BASE = "https://errordecoder.dev/api", AUTH_URL = "https://errordecoder.dev/auth", SITE_URL, getHeaders = async () => {
    const apiKey = await storage.get("apiKey");
    const headers = { "Content-Type": "application/json" };
    if (apiKey) {
      headers["Authorization"] = `Bearer ${apiKey}`;
    }
    return headers;
  }, request = async (path, options = {}) => {
    const headers = await getHeaders();
    const response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: { ...headers, ...options.headers }
    });
    return response.json();
  }, api;
  var init_api = __esm(() => {
    init_storage();
    SITE_URL = AUTH_URL.replace(/\/auth$/, "");
    api = {
      decode: (body) => request("/decode", {
        method: "POST",
        body: JSON.stringify(body)
      }),
      usage: () => request("/usage"),
      feedback: (body) => request("/feedback", {
        method: "POST",
        body: JSON.stringify(body)
      }),
      getApiKey: (supabaseJwt) => request("/auth/key", {
        method: "POST",
        headers: { Authorization: `Bearer ${supabaseJwt}` }
      }),
      checkout: (interval) => request("/checkout", {
        method: "POST",
        body: JSON.stringify({ interval })
      }),
      portal: () => request("/portal", { method: "POST" }),
      deleteAccount: () => request("/account", { method: "DELETE" })
    };
  });

  // packages/extension/src/options/index.ts
  init_storage();

  // packages/extension/src/shared/ui.ts
  var copyToClipboard = async (btn, getText, originalText = "Copy") => {
    const text = await Promise.resolve(getText());
    await navigator.clipboard.writeText(text);
    btn.textContent = "Copied!";
    setTimeout(() => {
      btn.textContent = originalText;
    }, 2000);
  };

  // packages/extension/src/shared/modal.ts
  var showConfirmModal = (options) => {
    const {
      title,
      message,
      confirmText = "Confirm",
      cancelText = "Cancel",
      confirmDanger = false
    } = options;
    return new Promise((resolve) => {
      const overlay = document.createElement("div");
      Object.assign(overlay.style, {
        position: "fixed",
        inset: "0",
        background: "rgba(0, 0, 0, 0.6)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: "99999",
        animation: "fadeIn 0.15s ease"
      });
      const card = document.createElement("div");
      Object.assign(card.style, {
        background: "var(--bg-secondary, #252526)",
        border: "1px solid var(--border, #3e3e3e)",
        borderRadius: "10px",
        padding: "24px",
        maxWidth: "360px",
        width: "90%",
        color: "var(--text, #d4d4d4)",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
        animation: "scaleIn 0.15s ease"
      });
      const titleEl = document.createElement("h3");
      titleEl.textContent = title;
      Object.assign(titleEl.style, {
        fontSize: "15px",
        fontWeight: "700",
        marginBottom: "8px",
        color: confirmDanger ? "var(--error-red, #f48771)" : "var(--text, #d4d4d4)"
      });
      const messageEl = document.createElement("p");
      messageEl.textContent = message;
      Object.assign(messageEl.style, {
        fontSize: "13px",
        lineHeight: "1.5",
        color: "var(--text-muted, #808080)",
        marginBottom: "20px"
      });
      const btnRow = document.createElement("div");
      Object.assign(btnRow.style, {
        display: "flex",
        gap: "8px",
        justifyContent: "flex-end"
      });
      const btnBase = {
        padding: "8px 16px",
        borderRadius: "6px",
        fontSize: "13px",
        fontWeight: "600",
        cursor: "pointer",
        border: "none"
      };
      const cancelBtn = document.createElement("button");
      cancelBtn.textContent = cancelText;
      Object.assign(cancelBtn.style, {
        ...btnBase,
        background: "var(--bg, #1e1e1e)",
        color: "var(--text-muted, #808080)",
        border: "1px solid var(--border, #3e3e3e)"
      });
      const confirmBtn = document.createElement("button");
      confirmBtn.textContent = confirmText;
      Object.assign(confirmBtn.style, {
        ...btnBase,
        background: confirmDanger ? "var(--error-red, #f48771)" : "var(--accent, #569cd6)",
        color: "white"
      });
      const cleanup = (result) => {
        overlay.remove();
        style.remove();
        resolve(result);
      };
      cancelBtn.addEventListener("click", () => cleanup(false));
      confirmBtn.addEventListener("click", () => cleanup(true));
      overlay.addEventListener("click", (e) => {
        if (e.target === overlay)
          cleanup(false);
      });
      const onKeydown = (e) => {
        if (e.key === "Escape") {
          document.removeEventListener("keydown", onKeydown);
          cleanup(false);
        }
      };
      document.addEventListener("keydown", onKeydown);
      const style = document.createElement("style");
      style.textContent = `
      @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
      @keyframes scaleIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
    `;
      document.head.appendChild(style);
      btnRow.appendChild(cancelBtn);
      btnRow.appendChild(confirmBtn);
      card.appendChild(titleEl);
      card.appendChild(messageEl);
      card.appendChild(btnRow);
      overlay.appendChild(card);
      document.body.appendChild(overlay);
      confirmBtn.focus();
    });
  };

  // packages/extension/src/options/index.ts
  init_api();
  document.getElementById("privacy-link")?.setAttribute("href", `${SITE_URL}/privacy`);
  document.getElementById("terms-link")?.setAttribute("href", `${SITE_URL}/terms`);
  var loadProfile = async () => {
    const email = await storage.get("userEmail");
    const plan = await storage.get("userPlan");
    const apiKey = await storage.get("apiKey");
    document.getElementById("email").textContent = email ?? "Not signed in";
    document.getElementById("plan").textContent = plan === "pro" ? "Pro" : "Free";
    document.getElementById("api-key").textContent = apiKey ? `${apiKey.slice(0, 8)}••••••••` : "Not set";
    const manualSection = document.getElementById("manual-key-section");
    manualSection.style.display = apiKey ? "none" : "block";
    const manageBtn = document.getElementById("manage-sub");
    if (!apiKey) {
      manageBtn.style.display = "none";
    } else {
      manageBtn.style.display = "inline-block";
      manageBtn.textContent = plan === "pro" ? "Manage Subscription" : "Upgrade to Pro";
    }
  };
  document.getElementById("save-key")?.addEventListener("click", async () => {
    const input = document.getElementById("manual-key-input");
    const statusEl = document.getElementById("save-status");
    const key = input.value.trim();
    if (!key)
      return;
    statusEl.textContent = "Validating key...";
    statusEl.style.color = "var(--accent)";
    await storage.set("apiKey", key);
    try {
      const { api: api2 } = await Promise.resolve().then(() => (init_api(), exports_api));
      const res = await api2.usage();
      if ("data" in res) {
        await storage.set("userPlan", res.data.plan);
        await storage.set("userEmail", res.data.email);
        statusEl.textContent = "Saved!";
        statusEl.style.color = "var(--accent)";
        input.value = "";
      } else {
        await storage.remove("apiKey");
        statusEl.textContent = "Invalid API key. Check and try again.";
        statusEl.style.color = "var(--error, #f44747)";
      }
    } catch {
      await storage.remove("apiKey");
      statusEl.textContent = "Could not validate key. Check your connection.";
      statusEl.style.color = "var(--error, #f44747)";
    }
    setTimeout(() => {
      statusEl.textContent = "";
    }, 4000);
    loadProfile();
  });
  document.getElementById("copy-key")?.addEventListener("click", async () => {
    const apiKey = await storage.get("apiKey");
    if (apiKey) {
      const btn = document.getElementById("copy-key");
      copyToClipboard(btn, () => apiKey, "Copy Key");
    }
  });
  document.getElementById("manage-sub")?.addEventListener("click", async () => {
    const plan = await storage.get("userPlan");
    const { api: api2, SITE_URL: SITE_URL2 } = await Promise.resolve().then(() => (init_api(), exports_api));
    if (plan === "pro") {
      const res = await api2.portal();
      if ("data" in res) {
        chrome.tabs.create({ url: res.data.url });
      }
    } else {
      chrome.tabs.create({ url: `${SITE_URL2}/#pricing` });
    }
  });
  document.getElementById("logout")?.addEventListener("click", async () => {
    await storage.clear();
    const { AUTH_URL: AUTH_URL2 } = await Promise.resolve().then(() => (init_api(), exports_api));
    chrome.tabs.create({ url: `${AUTH_URL2}?logout=true` });
    loadProfile();
  });
  document.getElementById("delete-account")?.addEventListener("click", async () => {
    const confirmed = await showConfirmModal({
      title: "Delete Account",
      message: "This will permanently delete your account, cancel your subscription, and erase all decode history. This cannot be undone.",
      confirmText: "Delete My Account",
      confirmDanger: true
    });
    if (!confirmed)
      return;
    const { api: api2, AUTH_URL: AUTH_URL2 } = await Promise.resolve().then(() => (init_api(), exports_api));
    await api2.deleteAccount();
    await storage.clear();
    chrome.tabs.create({ url: `${AUTH_URL2}?logout=true` });
    loadProfile();
  });
  chrome.storage.local.onChanged.addListener(() => {
    loadProfile();
  });
  loadProfile();
})();

//# debugId=DE3081280E3ADDBB64756E2164756E21
