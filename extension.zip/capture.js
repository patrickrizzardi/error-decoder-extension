(() => {
  // packages/extension/src/capture/main-world.ts
  if (!window.__errorDecoderActive) {
    window.__errorDecoderActive = true;
    const emit = (level, text) => {
      document.dispatchEvent(new CustomEvent("errordecoder-error", { detail: { level, text } }));
    };
    const origError = console.error;
    console.error = function(...args) {
      const text = args.map((a) => typeof a === "string" ? a : a instanceof Error ? a.message + (a.stack ? `
` + a.stack : "") : JSON.stringify(a)).join(" ");
      emit("error", text);
      origError.apply(console, args);
    };
    const origWarn = console.warn;
    console.warn = function(...args) {
      const text = args.map((a) => typeof a === "string" ? a : JSON.stringify(a)).join(" ");
      emit("warning", text);
      origWarn.apply(console, args);
    };
    window.addEventListener("error", (e) => {
      emit("error", e.message + (e.filename ? " at " + e.filename + ":" + e.lineno : ""));
    });
    window.addEventListener("unhandledrejection", (e) => {
      const reason = e.reason;
      emit("error", "Unhandled Promise Rejection: " + (reason instanceof Error ? reason.message + `
` + reason.stack : reason || "unknown"));
    });
    const origFetch = window.fetch;
    window.fetch = function(...args) {
      let url = args[0];
      if (typeof url === "object" && url.url)
        url = url.url;
      const urlStr = typeof url === "string" ? url : "unknown URL";
      return origFetch.apply(window, args).then((response) => {
        if (!response.ok) {
          emit("error", `Network Error: ${response.status} ${response.statusText} — ${urlStr}`);
        }
        return response;
      }).catch((err) => {
        emit("error", `Network Error: ${err.message || "fetch failed"} — ${urlStr}`);
        throw err;
      });
    };
    const origOpen = XMLHttpRequest.prototype.open;
    const origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url) {
      this.__edUrl = url;
      this.__edMethod = method;
      return origOpen.apply(this, arguments);
    };
    XMLHttpRequest.prototype.send = function() {
      const xhr = this;
      xhr.addEventListener("loadend", () => {
        if (xhr.status >= 400 || xhr.status === 0) {
          const text = xhr.status === 0 ? `Network Error: Request failed — ${xhr.__edMethod} ${xhr.__edUrl}` : `Network Error: ${xhr.status} ${xhr.statusText} — ${xhr.__edMethod} ${xhr.__edUrl}`;
          emit("error", text);
        }
      });
      return origSend.apply(this, arguments);
    };
    const detectGlobals = () => {
      const globals = {};
      if (window.__REACT_DEVTOOLS_GLOBAL_HOOK__)
        globals.react = true;
      if (window.React?.version)
        globals.reactVersion = window.React.version;
      if (window.__NEXT_DATA__)
        globals.nextjs = true;
      if (window.__VUE__)
        globals.vue = true;
      if (window.__VUE_DEVTOOLS_GLOBAL_HOOK__)
        globals.vue = true;
      if (window.__NUXT__)
        globals.nuxt = true;
      if (window.__SVELTE_HMR)
        globals.svelte = true;
      if (window.__remixContext)
        globals.remix = true;
      if (window.ng)
        globals.angular = true;
      if (window.__vite_plugin_react_preamble_installed__)
        globals.vite = true;
      if (window.webpackJsonp || window.__webpack_modules__)
        globals.webpack = true;
      if (window.__turbopack_require__)
        globals.turbopack = true;
      if (window.__REDUX_DEVTOOLS_EXTENSION__)
        globals.redux = true;
      if (window.jQuery || window.$?.fn?.jquery) {
        globals.jquery = true;
        globals.jqueryVersion = window.jQuery?.fn?.jquery || "";
      }
      if (window._?.VERSION)
        globals.lodash = window._.VERSION;
      if (window.axios)
        globals.axios = true;
      if (window._$HY)
        globals.solid = true;
      if (window.Ember)
        globals.ember = true;
      if (window.__PREACT_DEVTOOLS__)
        globals.preact = true;
      if (window.qwikCity || window.__qwik__)
        globals.qwik = true;
      if (window.__litDevMode)
        globals.lit = true;
      if (window.__ZUSTAND_DEVTOOLS__)
        globals.zustand = true;
      if (window.__mobxGlobals)
        globals.mobx = true;
      if (window.__pinia)
        globals.pinia = true;
      if (window.Apollo || window.__APOLLO_CLIENT__)
        globals.apollo = true;
      if (window.gsap || window.TweenMax)
        globals.gsap = true;
      if (window.Chart)
        globals.chart = true;
      if (window.firebase || window.__FIREBASE_DEFAULTS__)
        globals.firebase = true;
      if (window.ethereum)
        globals.ethereum = true;
      if (window.solana)
        globals.solana = true;
      if (window.web3)
        globals.web3 = true;
      if (window.Sentry)
        globals.sentry = true;
      document.documentElement.setAttribute("data-errordecoder-globals", JSON.stringify(globals));
    };
    setTimeout(detectGlobals, 1000);
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", detectGlobals);
    } else {
      detectGlobals();
    }
  }
})();

//# debugId=625C2166E861693D64756E2164756E21
