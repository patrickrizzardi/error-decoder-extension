(() => {
  // packages/extension/src/devtools/devtools.ts
  chrome.devtools.panels.create("ErrorDecoder", "icons/icon-16.png", "devtools/panel.html");
})();

//# debugId=4B0B1C509CA8E16564756E2164756E21
