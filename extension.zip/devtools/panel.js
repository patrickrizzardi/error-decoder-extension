(() => {
  // packages/extension/src/shared/html.ts
  var escapeHtml = (text) => text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  // packages/extension/src/shared/ui.ts
  var copyToClipboard = async (btn, getText, originalText = "Copy") => {
    const text = await Promise.resolve(getText());
    await navigator.clipboard.writeText(text);
    btn.textContent = "Copied!";
    setTimeout(() => {
      btn.textContent = originalText;
    }, 2000);
  };

  // packages/extension/src/shared/storage.ts
  var storage = {
    get: async (key) => {
      const result = await chrome.storage.local.get(key);
      return result[key];
    },
    set: async (key, value) => {
      await chrome.storage.local.set({ [key]: value });
    },
    remove: async (key) => {
      await chrome.storage.local.remove(key);
    },
    clear: async () => {
      await chrome.storage.local.clear();
    }
  };
  var getApiKey = () => storage.get("apiKey").then((key) => key || null);

  // packages/extension/src/shared/api.ts
  var API_BASE = "https://errordecoder.dev/api";
  var AUTH_URL = "https://errordecoder.dev/auth";
  var SITE_URL = AUTH_URL.replace(/\/auth$/, "");
  var getHeaders = async () => {
    const apiKey = await storage.get("apiKey");
    const headers = { "Content-Type": "application/json" };
    if (apiKey) {
      headers["Authorization"] = `Bearer ${apiKey}`;
    }
    return headers;
  };
  var request = async (path, options = {}) => {
    const headers = await getHeaders();
    const response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: { ...headers, ...options.headers }
    });
    return response.json();
  };
  var api = {
    decode: (body) => request("/decode", {
      method: "POST",
      body: JSON.stringify(body)
    }),
    usage: () => request("/usage"),
    feedback: (body) => request("/feedback", {
      method: "POST",
      body: JSON.stringify(body)
    }),
    getApiKey: (supabaseJwt) => request("/auth/key", {
      method: "POST",
      headers: { Authorization: `Bearer ${supabaseJwt}` }
    }),
    checkout: (interval) => request("/checkout", {
      method: "POST",
      body: JSON.stringify({ interval })
    }),
    portal: () => request("/portal", { method: "POST" }),
    deleteAccount: () => request("/account", { method: "DELETE" })
  };

  // packages/extension/src/devtools/panel.ts
  var errors = [];
  var errorListEl = document.getElementById("error-list");
  var emptyMsg = document.getElementById("empty-msg");
  var resultPlaceholder = document.getElementById("result-placeholder");
  var resultContent = document.getElementById("result-content");
  var resultLoading = document.getElementById("result-loading");
  var statusText = document.getElementById("status-text");
  var port = chrome.runtime.connect({ name: "devtools-panel" });
  port.onMessage.addListener((message) => {
    if (message.type === "DEVTOOLS_ERROR") {
      addError(message.text, message.level);
    }
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "DEVTOOLS_ERROR") {
      addError(message.text, message.level);
    }
  });
  statusText.textContent = "Listening for errors...";
  var addError = (text, level) => {
    const last = errors[errors.length - 1];
    if (last && last.text === text && Date.now() - last.timestamp < 500)
      return;
    errors.push({ text, level, timestamp: Date.now() });
    renderNewError(errors.length - 1);
    statusText.textContent = `${errors.length} error${errors.length !== 1 ? "s" : ""}`;
  };
  var renderNewError = (index) => {
    emptyMsg.style.display = "none";
    const err = errors[index];
    const item = document.createElement("div");
    item.className = "error-item";
    const firstLine = err.text.split(`
`)[0].slice(0, 200);
    item.innerHTML = `
    <div class="error-icon ${err.level}">${err.level === "error" ? "!" : "?"}</div>
    <div class="error-text" title="${escapeHtml(err.text)}">${escapeHtml(firstLine)}</div>
    <button class="error-decode-btn">Decode</button>
  `;
    item.querySelector(".error-decode-btn").addEventListener("click", (e) => {
      e.stopPropagation();
      selectItem(item);
      decodeError(err.text);
    });
    item.addEventListener("click", () => {
      selectItem(item);
      decodeError(err.text);
    });
    errorListEl.appendChild(item);
    errorListEl.scrollTop = errorListEl.scrollHeight;
  };
  var selectItem = (item) => {
    document.querySelectorAll(".error-item").forEach((el) => el.classList.remove("selected"));
    item.classList.add("selected");
  };
  var decodeError = async (errorText) => {
    const apiKey = await getApiKey();
    if (!apiKey) {
      showResult(`<p class="error-msg">API key not set. Go to extension options and paste your key.</p>`);
      return;
    }
    resultPlaceholder.style.display = "none";
    resultContent.style.display = "none";
    resultLoading.style.display = "block";
    try {
      const response = await api.decode({ errorText });
      if ("error" in response) {
        showResult(`<p class="error-msg">${escapeHtml(response.error.message)}</p>`);
        return;
      }
      const data = response.data;
      let html = "";
      html += `<h3>What Happened</h3><p>${escapeHtml(data.whatHappened)}</p>`;
      if (data.why?.length) {
        html += `<h3>Why This Occurs</h3><ul>${data.why.map((r) => `<li>${escapeHtml(r)}</li>`).join("")}</ul>`;
      }
      if (data.howToFix?.length) {
        html += `<h3>How to Fix</h3><ol>${data.howToFix.map((f) => `<li>${escapeHtml(f)}</li>`).join("")}</ol>`;
      }
      if (data.codeExample?.after) {
        html += `<h3>Code Example</h3>`;
        if (data.codeExample.before) {
          html += `<div class="code-block"><pre><code>${escapeHtml(data.codeExample.before)}</code></pre></div>`;
        }
        html += `<div class="code-block"><pre><code id="code-copy-target">${escapeHtml(data.codeExample.after)}</code></pre><button class="copy-btn" id="copy-result-code">Copy</button></div>`;
      }
      showResult(html);
      document.getElementById("copy-result-code")?.addEventListener("click", () => {
        const btn = document.getElementById("copy-result-code");
        copyToClipboard(btn, () => document.getElementById("code-copy-target")?.textContent ?? "");
      });
    } catch {
      showResult(`<p class="error-msg">Failed to connect to API. Is the server running?</p>`);
    }
  };
  var showResult = (html) => {
    resultPlaceholder.style.display = "none";
    resultLoading.style.display = "none";
    resultContent.style.display = "block";
    resultContent.innerHTML = html;
  };
  document.getElementById("clear-btn").addEventListener("click", () => {
    errors.length = 0;
    errorListEl.querySelectorAll(".error-item").forEach((el) => el.remove());
    emptyMsg.style.display = "block";
    resultPlaceholder.style.display = "flex";
    resultContent.style.display = "none";
    statusText.textContent = "Listening for errors...";
  });
  document.getElementById("paste-toggle").addEventListener("click", () => {
    document.getElementById("paste-area").classList.toggle("visible");
  });
  document.getElementById("paste-decode").addEventListener("click", () => {
    const input = document.getElementById("paste-input");
    const text = input.value.trim();
    if (text) {
      decodeError(text);
      input.value = "";
      document.getElementById("paste-area").classList.remove("visible");
    }
  });
})();

//# debugId=CA7C82F871C9EF4D64756E2164756E21
