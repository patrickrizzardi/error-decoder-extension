(() => {
  // node_modules/.bun/marked@17.0.5/node_modules/marked/lib/marked.esm.js
  function M() {
    return { async: false, breaks: false, extensions: null, gfm: true, hooks: null, pedantic: false, renderer: null, silent: false, tokenizer: null, walkTokens: null };
  }
  var T = M();
  function G(u) {
    T = u;
  }
  var _ = { exec: () => null };
  function k(u, e = "") {
    let t = typeof u == "string" ? u : u.source, n = { replace: (r, i) => {
      let s = typeof i == "string" ? i : i.source;
      return s = s.replace(m.caret, "$1"), t = t.replace(r, s), n;
    }, getRegex: () => new RegExp(t, e) };
    return n;
  }
  var be = (() => {
    try {
      return !!new RegExp("(?<=1)(?<!1)");
    } catch {
      return false;
    }
  })();
  var m = { codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm, outputLinkReplace: /\\([\[\]])/g, indentCodeCompensation: /^(\s+)(?:```)/, beginningSpace: /^\s+/, endingHash: /#$/, startingSpaceChar: /^ /, endingSpaceChar: / $/, nonSpaceChar: /[^ ]/, newLineCharGlobal: /\n/g, tabCharGlobal: /\t/g, multipleSpaceGlobal: /\s+/g, blankLine: /^[ \t]*$/, doubleBlankLine: /\n[ \t]*\n[ \t]*$/, blockquoteStart: /^ {0,3}>/, blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g, blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm, listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g, listIsTask: /^\[[ xX]\] +\S/, listReplaceTask: /^\[[ xX]\] +/, listTaskCheckbox: /\[[ xX]\]/, anyLine: /\n.*\n/, hrefBrackets: /^<(.*)>$/, tableDelimiter: /[:|]/, tableAlignChars: /^\||\| *$/g, tableRowBlankLine: /\n[ \t]*$/, tableAlignRight: /^ *-+: *$/, tableAlignCenter: /^ *:-+: *$/, tableAlignLeft: /^ *:-+ *$/, startATag: /^<a /i, endATag: /^<\/a>/i, startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i, endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i, startAngleBracket: /^</, endAngleBracket: />$/, pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/, unicodeAlphaNumeric: /[\p{L}\p{N}]/u, escapeTest: /[&<>"']/, escapeReplace: /[&<>"']/g, escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g, caret: /(^|[^\[])\^/g, percentDecode: /%25/g, findPipe: /\|/g, splitPipe: / \|/, slashPipe: /\\\|/g, carriageReturn: /\r\n|\r/g, spaceLine: /^ +$/gm, notSpaceStart: /^\S*/, endingNewline: /\n$/, listItemRegex: (u) => new RegExp(`^( {0,3}${u})((?:[	 ][^\\n]*)?(?:\\n|$))`), nextBulletRegex: (u) => new RegExp(`^ {0,${Math.min(3, u - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), hrRegex: (u) => new RegExp(`^ {0,${Math.min(3, u - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), fencesBeginRegex: (u) => new RegExp(`^ {0,${Math.min(3, u - 1)}}(?:\`\`\`|~~~)`), headingBeginRegex: (u) => new RegExp(`^ {0,${Math.min(3, u - 1)}}#`), htmlBeginRegex: (u) => new RegExp(`^ {0,${Math.min(3, u - 1)}}<(?:[a-z].*>|!--)`, "i"), blockquoteBeginRegex: (u) => new RegExp(`^ {0,${Math.min(3, u - 1)}}>`) };
  var Re = /^(?:[ \t]*(?:\n|$))+/;
  var Te = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/;
  var Oe = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/;
  var C = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/;
  var we = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/;
  var Q = / {0,3}(?:[*+-]|\d{1,9}[.)])/;
  var se = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/;
  var ie = k(se).replace(/bull/g, Q).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex();
  var ye = k(se).replace(/bull/g, Q).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex();
  var j = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/;
  var Pe = /^[^\n]+/;
  var F = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/;
  var Se = k(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", F).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex();
  var $e = k(/^(bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Q).getRegex();
  var v = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul";
  var U = /<!--(?:-?>|[\s\S]*?(?:-->|$))/;
  var _e = k("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ \t]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ \t]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ \t]*)+\\n|$))", "i").replace("comment", U).replace("tag", v).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex();
  var oe = k(j).replace("hr", C).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", v).getRegex();
  var Le = k(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", oe).getRegex();
  var K = { blockquote: Le, code: Te, def: Se, fences: Oe, heading: we, hr: C, html: _e, lheading: ie, list: $e, newline: Re, paragraph: oe, table: _, text: Pe };
  var ne = k("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", C).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}\t)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", v).getRegex();
  var Me = { ...K, lheading: ye, table: ne, paragraph: k(j).replace("hr", C).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", ne).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", v).getRegex() };
  var ze = { ...K, html: k(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", U).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(), def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/, heading: /^(#{1,6})(.*)(?:\n+|$)/, fences: _, lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/, paragraph: k(j).replace("hr", C).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", ie).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex() };
  var Ee = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/;
  var Ie = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/;
  var ae = /^( {2,}|\\)\n(?!\s*$)/;
  var Ae = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/;
  var z = /[\p{P}\p{S}]/u;
  var H = /[\s\p{P}\p{S}]/u;
  var W = /[^\s\p{P}\p{S}]/u;
  var Ce = k(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, H).getRegex();
  var le = /(?!~)[\p{P}\p{S}]/u;
  var Be = /(?!~)[\s\p{P}\p{S}]/u;
  var De = /(?:[^\s\p{P}\p{S}]|~)/u;
  var qe = k(/link|precode-code|html/, "g").replace("link", /\[(?:[^\[\]`]|(?<a>`+)[^`]+\k<a>(?!`))*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)/).replace("precode-", be ? "(?<!`)()" : "(^^|[^`])").replace("code", /(?<b>`+)[^`]+\k<b>(?!`)/).replace("html", /<(?! )[^<>]*?>/).getRegex();
  var ue = /^(?:\*+(?:((?!\*)punct)|([^\s*]))?)|^_+(?:((?!_)punct)|([^\s_]))?/;
  var ve = k(ue, "u").replace(/punct/g, z).getRegex();
  var He = k(ue, "u").replace(/punct/g, le).getRegex();
  var pe = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)";
  var Ze = k(pe, "gu").replace(/notPunctSpace/g, W).replace(/punctSpace/g, H).replace(/punct/g, z).getRegex();
  var Ge = k(pe, "gu").replace(/notPunctSpace/g, De).replace(/punctSpace/g, Be).replace(/punct/g, le).getRegex();
  var Ne = k("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)", "gu").replace(/notPunctSpace/g, W).replace(/punctSpace/g, H).replace(/punct/g, z).getRegex();
  var Qe = k(/^~~?(?:((?!~)punct)|[^\s~])/, "u").replace(/punct/g, z).getRegex();
  var je = "^[^~]+(?=[^~])|(?!~)punct(~~?)(?=[\\s]|$)|notPunctSpace(~~?)(?!~)(?=punctSpace|$)|(?!~)punctSpace(~~?)(?=notPunctSpace)|[\\s](~~?)(?!~)(?=punct)|(?!~)punct(~~?)(?!~)(?=punct)|notPunctSpace(~~?)(?=notPunctSpace)";
  var Fe = k(je, "gu").replace(/notPunctSpace/g, W).replace(/punctSpace/g, H).replace(/punct/g, z).getRegex();
  var Ue = k(/\\(punct)/, "gu").replace(/punct/g, z).getRegex();
  var Ke = k(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex();
  var We = k(U).replace("(?:-->|$)", "-->").getRegex();
  var Xe = k("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", We).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex();
  var q = /(?:\[(?:\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\])|[^\[\]\\`])*?/;
  var Je = k(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]+(?:\n[ \t]*)?|\n[ \t]*)(title))?\s*\)/).replace("label", q).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex();
  var ce = k(/^!?\[(label)\]\[(ref)\]/).replace("label", q).replace("ref", F).getRegex();
  var he = k(/^!?\[(ref)\](?:\[\])?/).replace("ref", F).getRegex();
  var Ve = k("reflink|nolink(?!\\()", "g").replace("reflink", ce).replace("nolink", he).getRegex();
  var re = /[hH][tT][tT][pP][sS]?|[fF][tT][pP]/;
  var X = { _backpedal: _, anyPunctuation: Ue, autolink: Ke, blockSkip: qe, br: ae, code: Ie, del: _, delLDelim: _, delRDelim: _, emStrongLDelim: ve, emStrongRDelimAst: Ze, emStrongRDelimUnd: Ne, escape: Ee, link: Je, nolink: he, punctuation: Ce, reflink: ce, reflinkSearch: Ve, tag: Xe, text: Ae, url: _ };
  var Ye = { ...X, link: k(/^!?\[(label)\]\((.*?)\)/).replace("label", q).getRegex(), reflink: k(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", q).getRegex() };
  var N = { ...X, emStrongRDelimAst: Ge, emStrongLDelim: He, delLDelim: Qe, delRDelim: Fe, url: k(/^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/).replace("protocol", re).replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(), _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/, del: /^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/, text: k(/^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/).replace("protocol", re).getRegex() };
  var et = { ...N, br: k(ae).replace("{2,}", "*").getRegex(), text: k(N.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex() };
  var B = { normal: K, gfm: Me, pedantic: ze };
  var E = { normal: X, gfm: N, breaks: et, pedantic: Ye };
  var tt = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
  var ke = (u) => tt[u];
  function O(u, e) {
    if (e) {
      if (m.escapeTest.test(u))
        return u.replace(m.escapeReplace, ke);
    } else if (m.escapeTestNoEncode.test(u))
      return u.replace(m.escapeReplaceNoEncode, ke);
    return u;
  }
  function J(u) {
    try {
      u = encodeURI(u).replace(m.percentDecode, "%");
    } catch {
      return null;
    }
    return u;
  }
  function V(u, e) {
    let t = u.replace(m.findPipe, (i, s, a) => {
      let o = false, l = s;
      for (;--l >= 0 && a[l] === "\\"; )
        o = !o;
      return o ? "|" : " |";
    }), n = t.split(m.splitPipe), r = 0;
    if (n[0].trim() || n.shift(), n.length > 0 && !n.at(-1)?.trim() && n.pop(), e)
      if (n.length > e)
        n.splice(e);
      else
        for (;n.length < e; )
          n.push("");
    for (;r < n.length; r++)
      n[r] = n[r].trim().replace(m.slashPipe, "|");
    return n;
  }
  function I(u, e, t) {
    let n = u.length;
    if (n === 0)
      return "";
    let r = 0;
    for (;r < n; ) {
      let i = u.charAt(n - r - 1);
      if (i === e && !t)
        r++;
      else if (i !== e && t)
        r++;
      else
        break;
    }
    return u.slice(0, n - r);
  }
  function de(u, e) {
    if (u.indexOf(e[1]) === -1)
      return -1;
    let t = 0;
    for (let n = 0;n < u.length; n++)
      if (u[n] === "\\")
        n++;
      else if (u[n] === e[0])
        t++;
      else if (u[n] === e[1] && (t--, t < 0))
        return n;
    return t > 0 ? -2 : -1;
  }
  function ge(u, e = 0) {
    let t = e, n = "";
    for (let r of u)
      if (r === "\t") {
        let i = 4 - t % 4;
        n += " ".repeat(i), t += i;
      } else
        n += r, t++;
    return n;
  }
  function fe(u, e, t, n, r) {
    let i = e.href, s = e.title || null, a = u[1].replace(r.other.outputLinkReplace, "$1");
    n.state.inLink = true;
    let o = { type: u[0].charAt(0) === "!" ? "image" : "link", raw: t, href: i, title: s, text: a, tokens: n.inlineTokens(a) };
    return n.state.inLink = false, o;
  }
  function nt(u, e, t) {
    let n = u.match(t.other.indentCodeCompensation);
    if (n === null)
      return e;
    let r = n[1];
    return e.split(`
`).map((i) => {
      let s = i.match(t.other.beginningSpace);
      if (s === null)
        return i;
      let [a] = s;
      return a.length >= r.length ? i.slice(r.length) : i;
    }).join(`
`);
  }
  var w = class {
    options;
    rules;
    lexer;
    constructor(e) {
      this.options = e || T;
    }
    space(e) {
      let t = this.rules.block.newline.exec(e);
      if (t && t[0].length > 0)
        return { type: "space", raw: t[0] };
    }
    code(e) {
      let t = this.rules.block.code.exec(e);
      if (t) {
        let n = t[0].replace(this.rules.other.codeRemoveIndent, "");
        return { type: "code", raw: t[0], codeBlockStyle: "indented", text: this.options.pedantic ? n : I(n, `
`) };
      }
    }
    fences(e) {
      let t = this.rules.block.fences.exec(e);
      if (t) {
        let n = t[0], r = nt(n, t[3] || "", this.rules);
        return { type: "code", raw: n, lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2], text: r };
      }
    }
    heading(e) {
      let t = this.rules.block.heading.exec(e);
      if (t) {
        let n = t[2].trim();
        if (this.rules.other.endingHash.test(n)) {
          let r = I(n, "#");
          (this.options.pedantic || !r || this.rules.other.endingSpaceChar.test(r)) && (n = r.trim());
        }
        return { type: "heading", raw: t[0], depth: t[1].length, text: n, tokens: this.lexer.inline(n) };
      }
    }
    hr(e) {
      let t = this.rules.block.hr.exec(e);
      if (t)
        return { type: "hr", raw: I(t[0], `
`) };
    }
    blockquote(e) {
      let t = this.rules.block.blockquote.exec(e);
      if (t) {
        let n = I(t[0], `
`).split(`
`), r = "", i = "", s = [];
        for (;n.length > 0; ) {
          let a = false, o = [], l;
          for (l = 0;l < n.length; l++)
            if (this.rules.other.blockquoteStart.test(n[l]))
              o.push(n[l]), a = true;
            else if (!a)
              o.push(n[l]);
            else
              break;
          n = n.slice(l);
          let p = o.join(`
`), c = p.replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
          r = r ? `${r}
${p}` : p, i = i ? `${i}
${c}` : c;
          let d = this.lexer.state.top;
          if (this.lexer.state.top = true, this.lexer.blockTokens(c, s, true), this.lexer.state.top = d, n.length === 0)
            break;
          let h = s.at(-1);
          if (h?.type === "code")
            break;
          if (h?.type === "blockquote") {
            let R = h, f = R.raw + `
` + n.join(`
`), S = this.blockquote(f);
            s[s.length - 1] = S, r = r.substring(0, r.length - R.raw.length) + S.raw, i = i.substring(0, i.length - R.text.length) + S.text;
            break;
          } else if (h?.type === "list") {
            let R = h, f = R.raw + `
` + n.join(`
`), S = this.list(f);
            s[s.length - 1] = S, r = r.substring(0, r.length - h.raw.length) + S.raw, i = i.substring(0, i.length - R.raw.length) + S.raw, n = f.substring(s.at(-1).raw.length).split(`
`);
            continue;
          }
        }
        return { type: "blockquote", raw: r, tokens: s, text: i };
      }
    }
    list(e) {
      let t = this.rules.block.list.exec(e);
      if (t) {
        let n = t[1].trim(), r = n.length > 1, i = { type: "list", raw: "", ordered: r, start: r ? +n.slice(0, -1) : "", loose: false, items: [] };
        n = r ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = r ? n : "[*+-]");
        let s = this.rules.other.listItemRegex(n), a = false;
        for (;e; ) {
          let l = false, p = "", c = "";
          if (!(t = s.exec(e)) || this.rules.block.hr.test(e))
            break;
          p = t[0], e = e.substring(p.length);
          let d = ge(t[2].split(`
`, 1)[0], t[1].length), h = e.split(`
`, 1)[0], R = !d.trim(), f = 0;
          if (this.options.pedantic ? (f = 2, c = d.trimStart()) : R ? f = t[1].length + 1 : (f = d.search(this.rules.other.nonSpaceChar), f = f > 4 ? 1 : f, c = d.slice(f), f += t[1].length), R && this.rules.other.blankLine.test(h) && (p += h + `
`, e = e.substring(h.length + 1), l = true), !l) {
            let S = this.rules.other.nextBulletRegex(f), Y = this.rules.other.hrRegex(f), ee = this.rules.other.fencesBeginRegex(f), te = this.rules.other.headingBeginRegex(f), me = this.rules.other.htmlBeginRegex(f), xe = this.rules.other.blockquoteBeginRegex(f);
            for (;e; ) {
              let Z = e.split(`
`, 1)[0], A;
              if (h = Z, this.options.pedantic ? (h = h.replace(this.rules.other.listReplaceNesting, "  "), A = h) : A = h.replace(this.rules.other.tabCharGlobal, "    "), ee.test(h) || te.test(h) || me.test(h) || xe.test(h) || S.test(h) || Y.test(h))
                break;
              if (A.search(this.rules.other.nonSpaceChar) >= f || !h.trim())
                c += `
` + A.slice(f);
              else {
                if (R || d.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || ee.test(d) || te.test(d) || Y.test(d))
                  break;
                c += `
` + h;
              }
              R = !h.trim(), p += Z + `
`, e = e.substring(Z.length + 1), d = A.slice(f);
            }
          }
          i.loose || (a ? i.loose = true : this.rules.other.doubleBlankLine.test(p) && (a = true)), i.items.push({ type: "list_item", raw: p, task: !!this.options.gfm && this.rules.other.listIsTask.test(c), loose: false, text: c, tokens: [] }), i.raw += p;
        }
        let o = i.items.at(-1);
        if (o)
          o.raw = o.raw.trimEnd(), o.text = o.text.trimEnd();
        else
          return;
        i.raw = i.raw.trimEnd();
        for (let l of i.items) {
          if (this.lexer.state.top = false, l.tokens = this.lexer.blockTokens(l.text, []), l.task) {
            if (l.text = l.text.replace(this.rules.other.listReplaceTask, ""), l.tokens[0]?.type === "text" || l.tokens[0]?.type === "paragraph") {
              l.tokens[0].raw = l.tokens[0].raw.replace(this.rules.other.listReplaceTask, ""), l.tokens[0].text = l.tokens[0].text.replace(this.rules.other.listReplaceTask, "");
              for (let c = this.lexer.inlineQueue.length - 1;c >= 0; c--)
                if (this.rules.other.listIsTask.test(this.lexer.inlineQueue[c].src)) {
                  this.lexer.inlineQueue[c].src = this.lexer.inlineQueue[c].src.replace(this.rules.other.listReplaceTask, "");
                  break;
                }
            }
            let p = this.rules.other.listTaskCheckbox.exec(l.raw);
            if (p) {
              let c = { type: "checkbox", raw: p[0] + " ", checked: p[0] !== "[ ]" };
              l.checked = c.checked, i.loose ? l.tokens[0] && ["paragraph", "text"].includes(l.tokens[0].type) && "tokens" in l.tokens[0] && l.tokens[0].tokens ? (l.tokens[0].raw = c.raw + l.tokens[0].raw, l.tokens[0].text = c.raw + l.tokens[0].text, l.tokens[0].tokens.unshift(c)) : l.tokens.unshift({ type: "paragraph", raw: c.raw, text: c.raw, tokens: [c] }) : l.tokens.unshift(c);
            }
          }
          if (!i.loose) {
            let p = l.tokens.filter((d) => d.type === "space"), c = p.length > 0 && p.some((d) => this.rules.other.anyLine.test(d.raw));
            i.loose = c;
          }
        }
        if (i.loose)
          for (let l of i.items) {
            l.loose = true;
            for (let p of l.tokens)
              p.type === "text" && (p.type = "paragraph");
          }
        return i;
      }
    }
    html(e) {
      let t = this.rules.block.html.exec(e);
      if (t)
        return { type: "html", block: true, raw: t[0], pre: t[1] === "pre" || t[1] === "script" || t[1] === "style", text: t[0] };
    }
    def(e) {
      let t = this.rules.block.def.exec(e);
      if (t) {
        let n = t[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), r = t[2] ? t[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", i = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
        return { type: "def", tag: n, raw: t[0], href: r, title: i };
      }
    }
    table(e) {
      let t = this.rules.block.table.exec(e);
      if (!t || !this.rules.other.tableDelimiter.test(t[2]))
        return;
      let n = V(t[1]), r = t[2].replace(this.rules.other.tableAlignChars, "").split("|"), i = t[3]?.trim() ? t[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], s = { type: "table", raw: t[0], header: [], align: [], rows: [] };
      if (n.length === r.length) {
        for (let a of r)
          this.rules.other.tableAlignRight.test(a) ? s.align.push("right") : this.rules.other.tableAlignCenter.test(a) ? s.align.push("center") : this.rules.other.tableAlignLeft.test(a) ? s.align.push("left") : s.align.push(null);
        for (let a = 0;a < n.length; a++)
          s.header.push({ text: n[a], tokens: this.lexer.inline(n[a]), header: true, align: s.align[a] });
        for (let a of i)
          s.rows.push(V(a, s.header.length).map((o, l) => ({ text: o, tokens: this.lexer.inline(o), header: false, align: s.align[l] })));
        return s;
      }
    }
    lheading(e) {
      let t = this.rules.block.lheading.exec(e);
      if (t) {
        let n = t[1].trim();
        return { type: "heading", raw: t[0], depth: t[2].charAt(0) === "=" ? 1 : 2, text: n, tokens: this.lexer.inline(n) };
      }
    }
    paragraph(e) {
      let t = this.rules.block.paragraph.exec(e);
      if (t) {
        let n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
        return { type: "paragraph", raw: t[0], text: n, tokens: this.lexer.inline(n) };
      }
    }
    text(e) {
      let t = this.rules.block.text.exec(e);
      if (t)
        return { type: "text", raw: t[0], text: t[0], tokens: this.lexer.inline(t[0]) };
    }
    escape(e) {
      let t = this.rules.inline.escape.exec(e);
      if (t)
        return { type: "escape", raw: t[0], text: t[1] };
    }
    tag(e) {
      let t = this.rules.inline.tag.exec(e);
      if (t)
        return !this.lexer.state.inLink && this.rules.other.startATag.test(t[0]) ? this.lexer.state.inLink = true : this.lexer.state.inLink && this.rules.other.endATag.test(t[0]) && (this.lexer.state.inLink = false), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(t[0]) ? this.lexer.state.inRawBlock = true : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(t[0]) && (this.lexer.state.inRawBlock = false), { type: "html", raw: t[0], inLink: this.lexer.state.inLink, inRawBlock: this.lexer.state.inRawBlock, block: false, text: t[0] };
    }
    link(e) {
      let t = this.rules.inline.link.exec(e);
      if (t) {
        let n = t[2].trim();
        if (!this.options.pedantic && this.rules.other.startAngleBracket.test(n)) {
          if (!this.rules.other.endAngleBracket.test(n))
            return;
          let s = I(n.slice(0, -1), "\\");
          if ((n.length - s.length) % 2 === 0)
            return;
        } else {
          let s = de(t[2], "()");
          if (s === -2)
            return;
          if (s > -1) {
            let o = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + s;
            t[2] = t[2].substring(0, s), t[0] = t[0].substring(0, o).trim(), t[3] = "";
          }
        }
        let r = t[2], i = "";
        if (this.options.pedantic) {
          let s = this.rules.other.pedanticHrefTitle.exec(r);
          s && (r = s[1], i = s[3]);
        } else
          i = t[3] ? t[3].slice(1, -1) : "";
        return r = r.trim(), this.rules.other.startAngleBracket.test(r) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(n) ? r = r.slice(1) : r = r.slice(1, -1)), fe(t, { href: r && r.replace(this.rules.inline.anyPunctuation, "$1"), title: i && i.replace(this.rules.inline.anyPunctuation, "$1") }, t[0], this.lexer, this.rules);
      }
    }
    reflink(e, t) {
      let n;
      if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
        let r = (n[2] || n[1]).replace(this.rules.other.multipleSpaceGlobal, " "), i = t[r.toLowerCase()];
        if (!i) {
          let s = n[0].charAt(0);
          return { type: "text", raw: s, text: s };
        }
        return fe(n, i, n[0], this.lexer, this.rules);
      }
    }
    emStrong(e, t, n = "") {
      let r = this.rules.inline.emStrongLDelim.exec(e);
      if (!r || !r[1] && !r[2] && !r[3] && !r[4] || r[4] && n.match(this.rules.other.unicodeAlphaNumeric))
        return;
      if (!(r[1] || r[3] || "") || !n || this.rules.inline.punctuation.exec(n)) {
        let s = [...r[0]].length - 1, a, o, l = s, p = 0, c = r[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
        for (c.lastIndex = 0, t = t.slice(-1 * e.length + s);(r = c.exec(t)) != null; ) {
          if (a = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !a)
            continue;
          if (o = [...a].length, r[3] || r[4]) {
            l += o;
            continue;
          } else if ((r[5] || r[6]) && s % 3 && !((s + o) % 3)) {
            p += o;
            continue;
          }
          if (l -= o, l > 0)
            continue;
          o = Math.min(o, o + l + p);
          let d = [...r[0]][0].length, h = e.slice(0, s + r.index + d + o);
          if (Math.min(s, o) % 2) {
            let f = h.slice(1, -1);
            return { type: "em", raw: h, text: f, tokens: this.lexer.inlineTokens(f) };
          }
          let R = h.slice(2, -2);
          return { type: "strong", raw: h, text: R, tokens: this.lexer.inlineTokens(R) };
        }
      }
    }
    codespan(e) {
      let t = this.rules.inline.code.exec(e);
      if (t) {
        let n = t[2].replace(this.rules.other.newLineCharGlobal, " "), r = this.rules.other.nonSpaceChar.test(n), i = this.rules.other.startingSpaceChar.test(n) && this.rules.other.endingSpaceChar.test(n);
        return r && i && (n = n.substring(1, n.length - 1)), { type: "codespan", raw: t[0], text: n };
      }
    }
    br(e) {
      let t = this.rules.inline.br.exec(e);
      if (t)
        return { type: "br", raw: t[0] };
    }
    del(e, t, n = "") {
      let r = this.rules.inline.delLDelim.exec(e);
      if (!r)
        return;
      if (!(r[1] || "") || !n || this.rules.inline.punctuation.exec(n)) {
        let s = [...r[0]].length - 1, a, o, l = s, p = this.rules.inline.delRDelim;
        for (p.lastIndex = 0, t = t.slice(-1 * e.length + s);(r = p.exec(t)) != null; ) {
          if (a = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !a || (o = [...a].length, o !== s))
            continue;
          if (r[3] || r[4]) {
            l += o;
            continue;
          }
          if (l -= o, l > 0)
            continue;
          o = Math.min(o, o + l);
          let c = [...r[0]][0].length, d = e.slice(0, s + r.index + c + o), h = d.slice(s, -s);
          return { type: "del", raw: d, text: h, tokens: this.lexer.inlineTokens(h) };
        }
      }
    }
    autolink(e) {
      let t = this.rules.inline.autolink.exec(e);
      if (t) {
        let n, r;
        return t[2] === "@" ? (n = t[1], r = "mailto:" + n) : (n = t[1], r = n), { type: "link", raw: t[0], text: n, href: r, tokens: [{ type: "text", raw: n, text: n }] };
      }
    }
    url(e) {
      let t;
      if (t = this.rules.inline.url.exec(e)) {
        let n, r;
        if (t[2] === "@")
          n = t[0], r = "mailto:" + n;
        else {
          let i;
          do
            i = t[0], t[0] = this.rules.inline._backpedal.exec(t[0])?.[0] ?? "";
          while (i !== t[0]);
          n = t[0], t[1] === "www." ? r = "http://" + t[0] : r = t[0];
        }
        return { type: "link", raw: t[0], text: n, href: r, tokens: [{ type: "text", raw: n, text: n }] };
      }
    }
    inlineText(e) {
      let t = this.rules.inline.text.exec(e);
      if (t) {
        let n = this.lexer.state.inRawBlock;
        return { type: "text", raw: t[0], text: t[0], escaped: n };
      }
    }
  };
  var x = class u {
    tokens;
    options;
    state;
    inlineQueue;
    tokenizer;
    constructor(e) {
      this.tokens = [], this.tokens.links = Object.create(null), this.options = e || T, this.options.tokenizer = this.options.tokenizer || new w, this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = { inLink: false, inRawBlock: false, top: true };
      let t = { other: m, block: B.normal, inline: E.normal };
      this.options.pedantic ? (t.block = B.pedantic, t.inline = E.pedantic) : this.options.gfm && (t.block = B.gfm, this.options.breaks ? t.inline = E.breaks : t.inline = E.gfm), this.tokenizer.rules = t;
    }
    static get rules() {
      return { block: B, inline: E };
    }
    static lex(e, t) {
      return new u(t).lex(e);
    }
    static lexInline(e, t) {
      return new u(t).inlineTokens(e);
    }
    lex(e) {
      e = e.replace(m.carriageReturn, `
`), this.blockTokens(e, this.tokens);
      for (let t = 0;t < this.inlineQueue.length; t++) {
        let n = this.inlineQueue[t];
        this.inlineTokens(n.src, n.tokens);
      }
      return this.inlineQueue = [], this.tokens;
    }
    blockTokens(e, t = [], n = false) {
      for (this.tokenizer.lexer = this, this.options.pedantic && (e = e.replace(m.tabCharGlobal, "    ").replace(m.spaceLine, ""));e; ) {
        let r;
        if (this.options.extensions?.block?.some((s) => (r = s.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), true) : false))
          continue;
        if (r = this.tokenizer.space(e)) {
          e = e.substring(r.raw.length);
          let s = t.at(-1);
          r.raw.length === 1 && s !== undefined ? s.raw += `
` : t.push(r);
          continue;
        }
        if (r = this.tokenizer.code(e)) {
          e = e.substring(r.raw.length);
          let s = t.at(-1);
          s?.type === "paragraph" || s?.type === "text" ? (s.raw += (s.raw.endsWith(`
`) ? "" : `
`) + r.raw, s.text += `
` + r.text, this.inlineQueue.at(-1).src = s.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.fences(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.heading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.hr(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.blockquote(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.list(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.html(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.def(e)) {
          e = e.substring(r.raw.length);
          let s = t.at(-1);
          s?.type === "paragraph" || s?.type === "text" ? (s.raw += (s.raw.endsWith(`
`) ? "" : `
`) + r.raw, s.text += `
` + r.raw, this.inlineQueue.at(-1).src = s.text) : this.tokens.links[r.tag] || (this.tokens.links[r.tag] = { href: r.href, title: r.title }, t.push(r));
          continue;
        }
        if (r = this.tokenizer.table(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.lheading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        let i = e;
        if (this.options.extensions?.startBlock) {
          let s = 1 / 0, a = e.slice(1), o;
          this.options.extensions.startBlock.forEach((l) => {
            o = l.call({ lexer: this }, a), typeof o == "number" && o >= 0 && (s = Math.min(s, o));
          }), s < 1 / 0 && s >= 0 && (i = e.substring(0, s + 1));
        }
        if (this.state.top && (r = this.tokenizer.paragraph(i))) {
          let s = t.at(-1);
          n && s?.type === "paragraph" ? (s.raw += (s.raw.endsWith(`
`) ? "" : `
`) + r.raw, s.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = s.text) : t.push(r), n = i.length !== e.length, e = e.substring(r.raw.length);
          continue;
        }
        if (r = this.tokenizer.text(e)) {
          e = e.substring(r.raw.length);
          let s = t.at(-1);
          s?.type === "text" ? (s.raw += (s.raw.endsWith(`
`) ? "" : `
`) + r.raw, s.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = s.text) : t.push(r);
          continue;
        }
        if (e) {
          let s = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(s);
            break;
          } else
            throw new Error(s);
        }
      }
      return this.state.top = true, t;
    }
    inline(e, t = []) {
      return this.inlineQueue.push({ src: e, tokens: t }), t;
    }
    inlineTokens(e, t = []) {
      this.tokenizer.lexer = this;
      let n = e, r = null;
      if (this.tokens.links) {
        let o = Object.keys(this.tokens.links);
        if (o.length > 0)
          for (;(r = this.tokenizer.rules.inline.reflinkSearch.exec(n)) != null; )
            o.includes(r[0].slice(r[0].lastIndexOf("[") + 1, -1)) && (n = n.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + n.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
      }
      for (;(r = this.tokenizer.rules.inline.anyPunctuation.exec(n)) != null; )
        n = n.slice(0, r.index) + "++" + n.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
      let i;
      for (;(r = this.tokenizer.rules.inline.blockSkip.exec(n)) != null; )
        i = r[2] ? r[2].length : 0, n = n.slice(0, r.index + i) + "[" + "a".repeat(r[0].length - i - 2) + "]" + n.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
      n = this.options.hooks?.emStrongMask?.call({ lexer: this }, n) ?? n;
      let s = false, a = "";
      for (;e; ) {
        s || (a = ""), s = false;
        let o;
        if (this.options.extensions?.inline?.some((p) => (o = p.call({ lexer: this }, e, t)) ? (e = e.substring(o.raw.length), t.push(o), true) : false))
          continue;
        if (o = this.tokenizer.escape(e)) {
          e = e.substring(o.raw.length), t.push(o);
          continue;
        }
        if (o = this.tokenizer.tag(e)) {
          e = e.substring(o.raw.length), t.push(o);
          continue;
        }
        if (o = this.tokenizer.link(e)) {
          e = e.substring(o.raw.length), t.push(o);
          continue;
        }
        if (o = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(o.raw.length);
          let p = t.at(-1);
          o.type === "text" && p?.type === "text" ? (p.raw += o.raw, p.text += o.text) : t.push(o);
          continue;
        }
        if (o = this.tokenizer.emStrong(e, n, a)) {
          e = e.substring(o.raw.length), t.push(o);
          continue;
        }
        if (o = this.tokenizer.codespan(e)) {
          e = e.substring(o.raw.length), t.push(o);
          continue;
        }
        if (o = this.tokenizer.br(e)) {
          e = e.substring(o.raw.length), t.push(o);
          continue;
        }
        if (o = this.tokenizer.del(e, n, a)) {
          e = e.substring(o.raw.length), t.push(o);
          continue;
        }
        if (o = this.tokenizer.autolink(e)) {
          e = e.substring(o.raw.length), t.push(o);
          continue;
        }
        if (!this.state.inLink && (o = this.tokenizer.url(e))) {
          e = e.substring(o.raw.length), t.push(o);
          continue;
        }
        let l = e;
        if (this.options.extensions?.startInline) {
          let p = 1 / 0, c = e.slice(1), d;
          this.options.extensions.startInline.forEach((h) => {
            d = h.call({ lexer: this }, c), typeof d == "number" && d >= 0 && (p = Math.min(p, d));
          }), p < 1 / 0 && p >= 0 && (l = e.substring(0, p + 1));
        }
        if (o = this.tokenizer.inlineText(l)) {
          e = e.substring(o.raw.length), o.raw.slice(-1) !== "_" && (a = o.raw.slice(-1)), s = true;
          let p = t.at(-1);
          p?.type === "text" ? (p.raw += o.raw, p.text += o.text) : t.push(o);
          continue;
        }
        if (e) {
          let p = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(p);
            break;
          } else
            throw new Error(p);
        }
      }
      return t;
    }
  };
  var y = class {
    options;
    parser;
    constructor(e) {
      this.options = e || T;
    }
    space(e) {
      return "";
    }
    code({ text: e, lang: t, escaped: n }) {
      let r = (t || "").match(m.notSpaceStart)?.[0], i = e.replace(m.endingNewline, "") + `
`;
      return r ? '<pre><code class="language-' + O(r) + '">' + (n ? i : O(i, true)) + `</code></pre>
` : "<pre><code>" + (n ? i : O(i, true)) + `</code></pre>
`;
    }
    blockquote({ tokens: e }) {
      return `<blockquote>
${this.parser.parse(e)}</blockquote>
`;
    }
    html({ text: e }) {
      return e;
    }
    def(e) {
      return "";
    }
    heading({ tokens: e, depth: t }) {
      return `<h${t}>${this.parser.parseInline(e)}</h${t}>
`;
    }
    hr(e) {
      return `<hr>
`;
    }
    list(e) {
      let { ordered: t, start: n } = e, r = "";
      for (let a = 0;a < e.items.length; a++) {
        let o = e.items[a];
        r += this.listitem(o);
      }
      let i = t ? "ol" : "ul", s = t && n !== 1 ? ' start="' + n + '"' : "";
      return "<" + i + s + `>
` + r + "</" + i + `>
`;
    }
    listitem(e) {
      return `<li>${this.parser.parse(e.tokens)}</li>
`;
    }
    checkbox({ checked: e }) {
      return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox"> ';
    }
    paragraph({ tokens: e }) {
      return `<p>${this.parser.parseInline(e)}</p>
`;
    }
    table(e) {
      let t = "", n = "";
      for (let i = 0;i < e.header.length; i++)
        n += this.tablecell(e.header[i]);
      t += this.tablerow({ text: n });
      let r = "";
      for (let i = 0;i < e.rows.length; i++) {
        let s = e.rows[i];
        n = "";
        for (let a = 0;a < s.length; a++)
          n += this.tablecell(s[a]);
        r += this.tablerow({ text: n });
      }
      return r && (r = `<tbody>${r}</tbody>`), `<table>
<thead>
` + t + `</thead>
` + r + `</table>
`;
    }
    tablerow({ text: e }) {
      return `<tr>
${e}</tr>
`;
    }
    tablecell(e) {
      let t = this.parser.parseInline(e.tokens), n = e.header ? "th" : "td";
      return (e.align ? `<${n} align="${e.align}">` : `<${n}>`) + t + `</${n}>
`;
    }
    strong({ tokens: e }) {
      return `<strong>${this.parser.parseInline(e)}</strong>`;
    }
    em({ tokens: e }) {
      return `<em>${this.parser.parseInline(e)}</em>`;
    }
    codespan({ text: e }) {
      return `<code>${O(e, true)}</code>`;
    }
    br(e) {
      return "<br>";
    }
    del({ tokens: e }) {
      return `<del>${this.parser.parseInline(e)}</del>`;
    }
    link({ href: e, title: t, tokens: n }) {
      let r = this.parser.parseInline(n), i = J(e);
      if (i === null)
        return r;
      e = i;
      let s = '<a href="' + e + '"';
      return t && (s += ' title="' + O(t) + '"'), s += ">" + r + "</a>", s;
    }
    image({ href: e, title: t, text: n, tokens: r }) {
      r && (n = this.parser.parseInline(r, this.parser.textRenderer));
      let i = J(e);
      if (i === null)
        return O(n);
      e = i;
      let s = `<img src="${e}" alt="${O(n)}"`;
      return t && (s += ` title="${O(t)}"`), s += ">", s;
    }
    text(e) {
      return "tokens" in e && e.tokens ? this.parser.parseInline(e.tokens) : ("escaped" in e) && e.escaped ? e.text : O(e.text);
    }
  };
  var $ = class {
    strong({ text: e }) {
      return e;
    }
    em({ text: e }) {
      return e;
    }
    codespan({ text: e }) {
      return e;
    }
    del({ text: e }) {
      return e;
    }
    html({ text: e }) {
      return e;
    }
    text({ text: e }) {
      return e;
    }
    link({ text: e }) {
      return "" + e;
    }
    image({ text: e }) {
      return "" + e;
    }
    br() {
      return "";
    }
    checkbox({ raw: e }) {
      return e;
    }
  };
  var b = class u2 {
    options;
    renderer;
    textRenderer;
    constructor(e) {
      this.options = e || T, this.options.renderer = this.options.renderer || new y, this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new $;
    }
    static parse(e, t) {
      return new u2(t).parse(e);
    }
    static parseInline(e, t) {
      return new u2(t).parseInline(e);
    }
    parse(e) {
      this.renderer.parser = this;
      let t = "";
      for (let n = 0;n < e.length; n++) {
        let r = e[n];
        if (this.options.extensions?.renderers?.[r.type]) {
          let s = r, a = this.options.extensions.renderers[s.type].call({ parser: this }, s);
          if (a !== false || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "def", "paragraph", "text"].includes(s.type)) {
            t += a || "";
            continue;
          }
        }
        let i = r;
        switch (i.type) {
          case "space": {
            t += this.renderer.space(i);
            break;
          }
          case "hr": {
            t += this.renderer.hr(i);
            break;
          }
          case "heading": {
            t += this.renderer.heading(i);
            break;
          }
          case "code": {
            t += this.renderer.code(i);
            break;
          }
          case "table": {
            t += this.renderer.table(i);
            break;
          }
          case "blockquote": {
            t += this.renderer.blockquote(i);
            break;
          }
          case "list": {
            t += this.renderer.list(i);
            break;
          }
          case "checkbox": {
            t += this.renderer.checkbox(i);
            break;
          }
          case "html": {
            t += this.renderer.html(i);
            break;
          }
          case "def": {
            t += this.renderer.def(i);
            break;
          }
          case "paragraph": {
            t += this.renderer.paragraph(i);
            break;
          }
          case "text": {
            t += this.renderer.text(i);
            break;
          }
          default: {
            let s = 'Token with "' + i.type + '" type was not found.';
            if (this.options.silent)
              return console.error(s), "";
            throw new Error(s);
          }
        }
      }
      return t;
    }
    parseInline(e, t = this.renderer) {
      this.renderer.parser = this;
      let n = "";
      for (let r = 0;r < e.length; r++) {
        let i = e[r];
        if (this.options.extensions?.renderers?.[i.type]) {
          let a = this.options.extensions.renderers[i.type].call({ parser: this }, i);
          if (a !== false || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(i.type)) {
            n += a || "";
            continue;
          }
        }
        let s = i;
        switch (s.type) {
          case "escape": {
            n += t.text(s);
            break;
          }
          case "html": {
            n += t.html(s);
            break;
          }
          case "link": {
            n += t.link(s);
            break;
          }
          case "image": {
            n += t.image(s);
            break;
          }
          case "checkbox": {
            n += t.checkbox(s);
            break;
          }
          case "strong": {
            n += t.strong(s);
            break;
          }
          case "em": {
            n += t.em(s);
            break;
          }
          case "codespan": {
            n += t.codespan(s);
            break;
          }
          case "br": {
            n += t.br(s);
            break;
          }
          case "del": {
            n += t.del(s);
            break;
          }
          case "text": {
            n += t.text(s);
            break;
          }
          default: {
            let a = 'Token with "' + s.type + '" type was not found.';
            if (this.options.silent)
              return console.error(a), "";
            throw new Error(a);
          }
        }
      }
      return n;
    }
  };
  var P = class {
    options;
    block;
    constructor(e) {
      this.options = e || T;
    }
    static passThroughHooks = new Set(["preprocess", "postprocess", "processAllTokens", "emStrongMask"]);
    static passThroughHooksRespectAsync = new Set(["preprocess", "postprocess", "processAllTokens"]);
    preprocess(e) {
      return e;
    }
    postprocess(e) {
      return e;
    }
    processAllTokens(e) {
      return e;
    }
    emStrongMask(e) {
      return e;
    }
    provideLexer() {
      return this.block ? x.lex : x.lexInline;
    }
    provideParser() {
      return this.block ? b.parse : b.parseInline;
    }
  };
  var D = class {
    defaults = M();
    options = this.setOptions;
    parse = this.parseMarkdown(true);
    parseInline = this.parseMarkdown(false);
    Parser = b;
    Renderer = y;
    TextRenderer = $;
    Lexer = x;
    Tokenizer = w;
    Hooks = P;
    constructor(...e) {
      this.use(...e);
    }
    walkTokens(e, t) {
      let n = [];
      for (let r of e)
        switch (n = n.concat(t.call(this, r)), r.type) {
          case "table": {
            let i = r;
            for (let s of i.header)
              n = n.concat(this.walkTokens(s.tokens, t));
            for (let s of i.rows)
              for (let a of s)
                n = n.concat(this.walkTokens(a.tokens, t));
            break;
          }
          case "list": {
            let i = r;
            n = n.concat(this.walkTokens(i.items, t));
            break;
          }
          default: {
            let i = r;
            this.defaults.extensions?.childTokens?.[i.type] ? this.defaults.extensions.childTokens[i.type].forEach((s) => {
              let a = i[s].flat(1 / 0);
              n = n.concat(this.walkTokens(a, t));
            }) : i.tokens && (n = n.concat(this.walkTokens(i.tokens, t)));
          }
        }
      return n;
    }
    use(...e) {
      let t = this.defaults.extensions || { renderers: {}, childTokens: {} };
      return e.forEach((n) => {
        let r = { ...n };
        if (r.async = this.defaults.async || r.async || false, n.extensions && (n.extensions.forEach((i) => {
          if (!i.name)
            throw new Error("extension name required");
          if ("renderer" in i) {
            let s = t.renderers[i.name];
            s ? t.renderers[i.name] = function(...a) {
              let o = i.renderer.apply(this, a);
              return o === false && (o = s.apply(this, a)), o;
            } : t.renderers[i.name] = i.renderer;
          }
          if ("tokenizer" in i) {
            if (!i.level || i.level !== "block" && i.level !== "inline")
              throw new Error("extension level must be 'block' or 'inline'");
            let s = t[i.level];
            s ? s.unshift(i.tokenizer) : t[i.level] = [i.tokenizer], i.start && (i.level === "block" ? t.startBlock ? t.startBlock.push(i.start) : t.startBlock = [i.start] : i.level === "inline" && (t.startInline ? t.startInline.push(i.start) : t.startInline = [i.start]));
          }
          "childTokens" in i && i.childTokens && (t.childTokens[i.name] = i.childTokens);
        }), r.extensions = t), n.renderer) {
          let i = this.defaults.renderer || new y(this.defaults);
          for (let s in n.renderer) {
            if (!(s in i))
              throw new Error(`renderer '${s}' does not exist`);
            if (["options", "parser"].includes(s))
              continue;
            let a = s, o = n.renderer[a], l = i[a];
            i[a] = (...p) => {
              let c = o.apply(i, p);
              return c === false && (c = l.apply(i, p)), c || "";
            };
          }
          r.renderer = i;
        }
        if (n.tokenizer) {
          let i = this.defaults.tokenizer || new w(this.defaults);
          for (let s in n.tokenizer) {
            if (!(s in i))
              throw new Error(`tokenizer '${s}' does not exist`);
            if (["options", "rules", "lexer"].includes(s))
              continue;
            let a = s, o = n.tokenizer[a], l = i[a];
            i[a] = (...p) => {
              let c = o.apply(i, p);
              return c === false && (c = l.apply(i, p)), c;
            };
          }
          r.tokenizer = i;
        }
        if (n.hooks) {
          let i = this.defaults.hooks || new P;
          for (let s in n.hooks) {
            if (!(s in i))
              throw new Error(`hook '${s}' does not exist`);
            if (["options", "block"].includes(s))
              continue;
            let a = s, o = n.hooks[a], l = i[a];
            P.passThroughHooks.has(s) ? i[a] = (p) => {
              if (this.defaults.async && P.passThroughHooksRespectAsync.has(s))
                return (async () => {
                  let d = await o.call(i, p);
                  return l.call(i, d);
                })();
              let c = o.call(i, p);
              return l.call(i, c);
            } : i[a] = (...p) => {
              if (this.defaults.async)
                return (async () => {
                  let d = await o.apply(i, p);
                  return d === false && (d = await l.apply(i, p)), d;
                })();
              let c = o.apply(i, p);
              return c === false && (c = l.apply(i, p)), c;
            };
          }
          r.hooks = i;
        }
        if (n.walkTokens) {
          let i = this.defaults.walkTokens, s = n.walkTokens;
          r.walkTokens = function(a) {
            let o = [];
            return o.push(s.call(this, a)), i && (o = o.concat(i.call(this, a))), o;
          };
        }
        this.defaults = { ...this.defaults, ...r };
      }), this;
    }
    setOptions(e) {
      return this.defaults = { ...this.defaults, ...e }, this;
    }
    lexer(e, t) {
      return x.lex(e, t ?? this.defaults);
    }
    parser(e, t) {
      return b.parse(e, t ?? this.defaults);
    }
    parseMarkdown(e) {
      return (n, r) => {
        let i = { ...r }, s = { ...this.defaults, ...i }, a = this.onError(!!s.silent, !!s.async);
        if (this.defaults.async === true && i.async === false)
          return a(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
        if (typeof n > "u" || n === null)
          return a(new Error("marked(): input parameter is undefined or null"));
        if (typeof n != "string")
          return a(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
        if (s.hooks && (s.hooks.options = s, s.hooks.block = e), s.async)
          return (async () => {
            let o = s.hooks ? await s.hooks.preprocess(n) : n, p = await (s.hooks ? await s.hooks.provideLexer() : e ? x.lex : x.lexInline)(o, s), c = s.hooks ? await s.hooks.processAllTokens(p) : p;
            s.walkTokens && await Promise.all(this.walkTokens(c, s.walkTokens));
            let h = await (s.hooks ? await s.hooks.provideParser() : e ? b.parse : b.parseInline)(c, s);
            return s.hooks ? await s.hooks.postprocess(h) : h;
          })().catch(a);
        try {
          s.hooks && (n = s.hooks.preprocess(n));
          let l = (s.hooks ? s.hooks.provideLexer() : e ? x.lex : x.lexInline)(n, s);
          s.hooks && (l = s.hooks.processAllTokens(l)), s.walkTokens && this.walkTokens(l, s.walkTokens);
          let c = (s.hooks ? s.hooks.provideParser() : e ? b.parse : b.parseInline)(l, s);
          return s.hooks && (c = s.hooks.postprocess(c)), c;
        } catch (o) {
          return a(o);
        }
      };
    }
    onError(e, t) {
      return (n) => {
        if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
          let r = "<p>An error occurred:</p><pre>" + O(n.message + "", true) + "</pre>";
          return t ? Promise.resolve(r) : r;
        }
        if (t)
          return Promise.reject(n);
        throw n;
      };
    }
  };
  var L = new D;
  function g(u3, e) {
    return L.parse(u3, e);
  }
  g.options = g.setOptions = function(u3) {
    return L.setOptions(u3), g.defaults = L.defaults, G(g.defaults), g;
  };
  g.getDefaults = M;
  g.defaults = T;
  g.use = function(...u3) {
    return L.use(...u3), g.defaults = L.defaults, G(g.defaults), g;
  };
  g.walkTokens = function(u3, e) {
    return L.walkTokens(u3, e);
  };
  g.parseInline = L.parseInline;
  g.Parser = b;
  g.parser = b.parse;
  g.Renderer = y;
  g.TextRenderer = $;
  g.Lexer = x;
  g.lexer = x.lex;
  g.Tokenizer = w;
  g.Hooks = P;
  g.parse = g;
  var Qt = g.options;
  var jt = g.setOptions;
  var Ft = g.use;
  var Ut = g.walkTokens;
  var Kt = g.parseInline;
  var Xt = b.parse;
  var Jt = x.lex;

  // packages/extension/src/shared/html.ts
  var escapeHtml = (text) => text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  // packages/extension/src/shared/ui.ts
  var setupResizableGrip = (element, grip, minHeight = 40) => {
    let isDragging = false;
    let startY = 0;
    let startHeight = 0;
    grip.addEventListener("mousedown", (e) => {
      isDragging = true;
      startY = e.clientY;
      startHeight = element.offsetHeight;
      e.preventDefault();
      const pill = grip.querySelector(".textarea-grip-pill");
      if (pill)
        pill.style.background = "rgba(86, 156, 214, 0.8)";
    });
    document.addEventListener("mousemove", (e) => {
      if (!isDragging)
        return;
      const delta = e.clientY - startY;
      element.style.height = `${Math.max(minHeight, startHeight + delta)}px`;
    });
    document.addEventListener("mouseup", () => {
      if (!isDragging)
        return;
      isDragging = false;
      const pill = grip.querySelector(".textarea-grip-pill");
      if (pill)
        pill.style.background = "";
    });
  };
  var copyToClipboard = async (btn, getText, originalText = "Copy") => {
    const text = await Promise.resolve(getText());
    await navigator.clipboard.writeText(text);
    btn.textContent = "Copied!";
    setTimeout(() => {
      btn.textContent = originalText;
    }, 2000);
  };

  // packages/extension/src/shared/storage.ts
  var storage = {
    get: async (key) => {
      const result = await chrome.storage.local.get(key);
      return result[key];
    },
    set: async (key, value) => {
      await chrome.storage.local.set({ [key]: value });
    },
    remove: async (key) => {
      await chrome.storage.local.remove(key);
    },
    clear: async () => {
      await chrome.storage.local.clear();
    }
  };
  var getApiKey = () => storage.get("apiKey").then((key) => key || null);

  // packages/extension/src/shared/api.ts
  var API_BASE = "https://errordecoder.dev/api";
  var AUTH_URL = "https://errordecoder.dev/auth";
  var SITE_URL = AUTH_URL.replace(/\/auth$/, "");
  var getHeaders = async () => {
    const apiKey = await storage.get("apiKey");
    const headers = { "Content-Type": "application/json" };
    if (apiKey) {
      headers["Authorization"] = `Bearer ${apiKey}`;
    }
    return headers;
  };
  var request = async (path, options = {}) => {
    const headers = await getHeaders();
    const response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: { ...headers, ...options.headers }
    });
    return response.json();
  };
  var api = {
    decode: (body) => request("/decode", {
      method: "POST",
      body: JSON.stringify(body)
    }),
    usage: () => request("/usage"),
    feedback: (body) => request("/feedback", {
      method: "POST",
      body: JSON.stringify(body)
    }),
    getApiKey: (supabaseJwt) => request("/auth/key", {
      method: "POST",
      headers: { Authorization: `Bearer ${supabaseJwt}` }
    }),
    checkout: (interval) => request("/checkout", {
      method: "POST",
      body: JSON.stringify({ interval })
    }),
    portal: () => request("/portal", { method: "POST" }),
    deleteAccount: () => request("/account", { method: "DELETE" })
  };

  // packages/extension/src/shared/sensitive-check.ts
  var patterns = [
    { type: "AWS Access Key", regex: /AKIA[A-Z0-9]{16}/ },
    { type: "AWS Secret Key", regex: /aws.{0,10}secret.{0,10}[=:]\s*["']?[A-Za-z0-9/+=]{40}/i },
    { type: "Stripe Key", regex: /(sk|pk|rk)_(live|test)_[a-zA-Z0-9]{10,}/ },
    { type: "Anthropic Key", regex: /sk-ant-[a-zA-Z0-9_-]{20,}/ },
    { type: "OpenAI Key", regex: /sk-[a-zA-Z0-9]{20,}/ },
    { type: "GitHub Token", regex: /(ghp|gho|ghs|ghr)_[a-zA-Z0-9]{36}/ },
    { type: "GitLab Token", regex: /glpat-[a-zA-Z0-9_-]{20}/ },
    { type: "Slack Token", regex: /xox[bpas]-[a-zA-Z0-9-]{10,}/ },
    { type: "npm Token", regex: /npm_[a-zA-Z0-9]{36}/ },
    { type: "Supabase Key", regex: /sbp_[a-zA-Z0-9]{20,}/ },
    { type: "Social Security Number", regex: /\b\d{3}-\d{2}-\d{4}\b/ },
    { type: "Credit Card (Visa)", regex: /\b4\d{3}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/ },
    { type: "Credit Card (Mastercard)", regex: /\b5[1-5]\d{2}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/ },
    { type: "Credit Card (Amex)", regex: /\b3[47]\d{2}[\s-]?\d{6}[\s-]?\d{5}\b/ },
    { type: "Credit Card (Discover)", regex: /\b6(?:011|5\d{2})[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/ },
    { type: "Bank Account/Routing Number", regex: /\b(routing|account)[_\s-]?(number|num|no)?[=:]\s*["']?\d{8,17}/i },
    { type: "Date of Birth", regex: /\b(dob|date.of.birth|birthday)[=:]\s*["']?\d{1,4}[-/]\d{1,2}[-/]\d{1,4}/i },
    { type: "Passport Number", regex: /passport[_\s-]?(number|num|no)?[=:]\s*["']?[A-Z0-9]{6,12}/i },
    { type: "Driver's License", regex: /driver.?s?.?licen[sc]e[_\s-]?(number|num|no)?[=:]\s*["']?[A-Z0-9]{5,15}/i },
    { type: "Private Key", regex: /-----BEGIN[\s\w]*PRIVATE KEY-----/ },
    { type: "JWT Token", regex: /eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}/ },
    { type: "Bearer Token", regex: /Bearer\s+[a-zA-Z0-9._\-]{20,}/ },
    { type: "Connection String", regex: /(postgres|mysql|mongodb|redis|amqp):\/\/[^\s]{10,}/ },
    { type: "Password", regex: /password[=:]\s*["']?[^\s"']{4,}/i },
    { type: "API Key (generic)", regex: /api[_-]?key[=:]\s*["']?[a-zA-Z0-9_-]{16,}/i },
    { type: "Secret (generic)", regex: /secret[_-]?key[=:]\s*["']?[a-zA-Z0-9_-]{16,}/i }
  ];
  var redact = (match) => {
    if (match.length <= 12)
      return match.slice(0, 4) + "***";
    return match.slice(0, 6) + "..." + match.slice(-4);
  };
  var checkSensitiveData = (text) => {
    const matches = [];
    const seen = new Set;
    for (const { type, regex } of patterns) {
      const match = text.match(regex);
      if (match && !seen.has(type)) {
        seen.add(type);
        matches.push({ type, preview: redact(match[0]) });
      }
    }
    return matches;
  };
  var formatSensitiveWarning = (matches) => {
    const list = matches.map((m2) => `• ${m2.type}: ${m2.preview}`).join(`
`);
    return `Possible sensitive data detected:

${list}

This text will be sent to our API and processed by AI. Consider removing secrets before decoding.`;
  };

  // packages/extension/src/shared/modal.ts
  var showConfirmModal = (options) => {
    const {
      title,
      message,
      confirmText = "Confirm",
      cancelText = "Cancel",
      confirmDanger = false
    } = options;
    return new Promise((resolve) => {
      const overlay = document.createElement("div");
      Object.assign(overlay.style, {
        position: "fixed",
        inset: "0",
        background: "rgba(0, 0, 0, 0.6)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: "99999",
        animation: "fadeIn 0.15s ease"
      });
      const card = document.createElement("div");
      Object.assign(card.style, {
        background: "var(--bg-secondary, #252526)",
        border: "1px solid var(--border, #3e3e3e)",
        borderRadius: "10px",
        padding: "24px",
        maxWidth: "360px",
        width: "90%",
        color: "var(--text, #d4d4d4)",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
        animation: "scaleIn 0.15s ease"
      });
      const titleEl = document.createElement("h3");
      titleEl.textContent = title;
      Object.assign(titleEl.style, {
        fontSize: "15px",
        fontWeight: "700",
        marginBottom: "8px",
        color: confirmDanger ? "var(--error-red, #f48771)" : "var(--text, #d4d4d4)"
      });
      const messageEl = document.createElement("p");
      messageEl.textContent = message;
      Object.assign(messageEl.style, {
        fontSize: "13px",
        lineHeight: "1.5",
        color: "var(--text-muted, #808080)",
        marginBottom: "20px"
      });
      const btnRow = document.createElement("div");
      Object.assign(btnRow.style, {
        display: "flex",
        gap: "8px",
        justifyContent: "flex-end"
      });
      const btnBase = {
        padding: "8px 16px",
        borderRadius: "6px",
        fontSize: "13px",
        fontWeight: "600",
        cursor: "pointer",
        border: "none"
      };
      const cancelBtn = document.createElement("button");
      cancelBtn.textContent = cancelText;
      Object.assign(cancelBtn.style, {
        ...btnBase,
        background: "var(--bg, #1e1e1e)",
        color: "var(--text-muted, #808080)",
        border: "1px solid var(--border, #3e3e3e)"
      });
      const confirmBtn = document.createElement("button");
      confirmBtn.textContent = confirmText;
      Object.assign(confirmBtn.style, {
        ...btnBase,
        background: confirmDanger ? "var(--error-red, #f48771)" : "var(--accent, #569cd6)",
        color: "white"
      });
      const cleanup = (result) => {
        overlay.remove();
        style.remove();
        resolve(result);
      };
      cancelBtn.addEventListener("click", () => cleanup(false));
      confirmBtn.addEventListener("click", () => cleanup(true));
      overlay.addEventListener("click", (e) => {
        if (e.target === overlay)
          cleanup(false);
      });
      const onKeydown = (e) => {
        if (e.key === "Escape") {
          document.removeEventListener("keydown", onKeydown);
          cleanup(false);
        }
      };
      document.addEventListener("keydown", onKeydown);
      const style = document.createElement("style");
      style.textContent = `
      @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
      @keyframes scaleIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
    `;
      document.head.appendChild(style);
      btnRow.appendChild(cancelBtn);
      btnRow.appendChild(confirmBtn);
      card.appendChild(titleEl);
      card.appendChild(messageEl);
      card.appendChild(btnRow);
      overlay.appendChild(card);
      document.body.appendChild(overlay);
      confirmBtn.focus();
    });
  };

  // packages/extension/src/sidepanel/index.ts
  var decodeGrip = document.getElementById("textarea-grip");
  var decodeTextarea = document.getElementById("decode-input");
  if (decodeGrip && decodeTextarea)
    setupResizableGrip(decodeTextarea, decodeGrip);
  var inspectGrip = document.getElementById("inspect-question-grip");
  var inspectTextarea = document.getElementById("inspect-question");
  if (inspectGrip && inspectTextarea)
    setupResizableGrip(inspectTextarea, inspectGrip, 32);
  var elementInfoGrip = document.getElementById("element-info-grip");
  var elementInfo = document.getElementById("element-info");
  if (elementInfoGrip && elementInfo)
    setupResizableGrip(elementInfo, elementInfoGrip, 60);
  var renderedCount = 0;
  var tabs = document.querySelectorAll(".tab");
  var tabContents = document.querySelectorAll(".tab-content");
  var switchTab = (tabName) => {
    tabs.forEach((t) => t.classList.toggle("active", t.dataset.tab === tabName));
    tabContents.forEach((c) => c.classList.toggle("active", c.id === `tab-${tabName}`));
  };
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => switchTab(tab.dataset.tab));
  });
  var errorFeed = document.getElementById("error-feed");
  var emptyState = document.getElementById("empty-state");
  var feedActions = document.getElementById("feed-actions");
  var errorCountEl = document.getElementById("error-count");
  var errorBadge = document.getElementById("error-badge");
  var statusEl = document.getElementById("status");
  var currentTabId = null;
  var getTabKey = () => currentTabId ? `errors_tab_${currentTabId}` : null;
  var resolveTabId = async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    currentTabId = tab?.id ?? null;
    return currentTabId;
  };
  chrome.storage.session.onChanged.addListener((changes) => {
    const key = getTabKey();
    if (key && changes[key]) {
      renderNewErrors(changes[key].newValue || []);
    }
    if (changes.pendingText?.newValue) {
      const textarea = document.getElementById("decode-input");
      textarea.value = changes.pendingText.newValue;
      switchTab("decode");
      chrome.storage.session.remove("pendingText");
    }
    if (changes.selectedElement?.newValue) {
      showInspectResult(changes.selectedElement.newValue);
    }
    if ("selectedElement" in changes && changes.selectedElement.newValue === undefined && changes.selectedElement.oldValue !== undefined) {
      if (!inspectCancelBtn.classList.contains("hidden")) {
        cancelInspect();
      }
    }
    if (currentTabId) {
      const techKey = `tech_tab_${currentTabId}`;
      if (changes[techKey]?.newValue) {
        renderTechBar(changes[techKey].newValue);
      }
    }
  });
  chrome.storage.local.onChanged.addListener((changes) => {
    if (changes.apiKey) {
      if (changes.apiKey.newValue) {
        document.querySelectorAll(".auth-prompt").forEach((el) => {
          el.innerHTML = `<p style="color: var(--success);">Signed in! You can now decode errors.</p>`;
        });
        loadUserPlan();
      } else {
        window.location.reload();
        return;
      }
    }
    if (changes.userPlan?.newValue || changes.planRefreshAt) {
      loadUserPlan();
    }
  });
  var init = async () => {
    await resolveTabId();
    const key = getTabKey();
    if (key) {
      const result = await chrome.storage.session.get(key);
      const errors = result[key] || [];
      if (errors.length > 0)
        renderNewErrors(errors);
    }
    const { pendingText } = await chrome.storage.session.get("pendingText");
    if (pendingText) {
      const textarea = document.getElementById("decode-input");
      textarea.value = pendingText;
      switchTab("decode");
      chrome.storage.session.remove("pendingText");
    }
    loadTechStack();
    loadUserPlan();
  };
  init();
  var renderNewErrors = (errors) => {
    for (let i = renderedCount;i < errors.length; i++) {
      renderErrorItem(errors[i], i);
    }
    renderedCount = errors.length;
    updateCounts(errors.length);
  };
  var selectedErrors = new Set;
  var renderErrorItem = (err, index) => {
    emptyState.classList.add("hidden");
    feedActions.classList.remove("hidden");
    const firstLine = err.text.split(`
`)[0].slice(0, 150);
    const time = new Date(err.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    const levelClass = err.level === "warning" ? "warning" : err.text.startsWith("Network") ? "network" : "error";
    const item = document.createElement("div");
    item.className = "error-item";
    item.dataset.index = String(index);
    item.innerHTML = `
    <input type="checkbox" class="error-checkbox" data-index="${index}" />
    <div class="error-badge ${levelClass}"></div>
    <div class="error-info">
      <div class="error-text">${escapeHtml(firstLine)}</div>
      <div class="error-meta">${escapeHtml(err.domain || "")}</div>
    </div>
    <div class="error-time">${time}</div>
  `;
    const checkbox = item.querySelector(".error-checkbox");
    checkbox.addEventListener("click", (e) => {
      e.stopPropagation();
      if (checkbox.checked) {
        selectedErrors.add(index);
        item.classList.add("selected");
      } else {
        selectedErrors.delete(index);
        item.classList.remove("selected");
      }
      updateSelectionUI();
    });
    item.addEventListener("click", (e) => {
      if (e.target.tagName === "INPUT")
        return;
      checkbox.checked = !checkbox.checked;
      checkbox.dispatchEvent(new Event("click"));
    });
    errorFeed.appendChild(item);
    errorFeed.scrollTop = errorFeed.scrollHeight;
  };
  var updateSelectionUI = () => {
    const count = selectedErrors.size;
    const decodeSelectedBtn = document.getElementById("decode-selected");
    decodeSelectedBtn.disabled = count === 0;
    decodeSelectedBtn.textContent = count > 0 ? `Decode Selected (${count})` : "Decode Selected";
  };
  var updateCounts = (count) => {
    errorCountEl.textContent = `${count} error${count !== 1 ? "s" : ""}`;
    statusEl.textContent = `${count} captured`;
    errorBadge.textContent = String(count);
    errorBadge.classList.toggle("hidden", count === 0);
  };
  document.getElementById("decode-selected").addEventListener("click", async () => {
    if (selectedErrors.size === 0)
      return;
    const key = getTabKey();
    if (!key)
      return;
    const result = await chrome.storage.session.get(key);
    const allErrors = result[key] || [];
    const selected = [...selectedErrors].sort().map((i) => allErrors[i]).filter(Boolean);
    if (selected.length === 0)
      return;
    const textarea = document.getElementById("decode-input");
    if (selected.length === 1) {
      textarea.value = selected[0].text;
    } else {
      textarea.value = selected.map((e, i) => `Error ${i + 1} [${e.level}]: ${e.text}`).join(`

`);
    }
    switchTab("decode");
  });
  document.getElementById("decode-all").addEventListener("click", async () => {
    const key = getTabKey();
    if (!key)
      return;
    const result = await chrome.storage.session.get(key);
    const recent = (result[key] || []).slice(-15);
    if (recent.length === 0)
      return;
    const textarea = document.getElementById("decode-input");
    textarea.value = recent.map((e, i) => `Error ${i + 1} [${e.level}]: ${e.text}`).join(`

`);
    switchTab("decode");
  });
  document.getElementById("clear-errors").addEventListener("click", async () => {
    const key = getTabKey();
    if (key)
      await chrome.storage.session.set({ [key]: [] });
    renderedCount = 0;
    errorFeed.querySelectorAll(".error-item").forEach((el) => el.remove());
    emptyState.classList.remove("hidden");
    feedActions.classList.add("hidden");
    updateCounts(0);
  });
  var detectedTech = [];
  var loadTechStack = async () => {
    if (!currentTabId)
      return;
    const key = `tech_tab_${currentTabId}`;
    const result = await chrome.storage.session.get(key);
    const tech = result[key];
    if (tech?.length)
      renderTechBar(tech);
  };
  var renderTechBar = (tech) => {
    detectedTech = tech;
    const bar = document.getElementById("tech-bar");
    if (tech.length === 0) {
      bar.classList.add("hidden");
      return;
    }
    bar.classList.remove("hidden");
    bar.innerHTML = tech.map((t) => `<span class="tech-badge" style="background:${t.color}" title="${t.name}${t.version ? ` v${t.version}` : ""} (${t.category})">${t.name}</span>`).join("");
  };
  var getTechContext = () => {
    if (detectedTech.length === 0)
      return "";
    const techs = detectedTech.map((t) => `${t.name}${t.version ? ` v${t.version}` : ""}`).join(", ");
    return `

Detected tech stack: ${techs}`;
  };
  var decodeInput = document.getElementById("decode-input");
  var decodeResult = document.getElementById("decode-result");
  var sonnetBtn = document.getElementById("decode-sonnet");
  var sonnetRemaining = document.getElementById("sonnet-remaining");
  var haikuRemaining = document.getElementById("haiku-remaining");
  var usageBar = document.getElementById("usage-bar");
  var updateUsageDisplay = (used, limit, plan) => {
    if (plan === "pro") {
      haikuRemaining.textContent = "";
      haikuBtn.disabled = false;
      usageBar.classList.add("hidden");
      return;
    }
    const remaining = Math.max(0, limit - used);
    haikuRemaining.textContent = `(${remaining} left)`;
    usageBar.classList.remove("hidden");
    if (remaining === 0) {
      haikuBtn.disabled = true;
      haikuRemaining.textContent = "(limit reached)";
      usageBar.className = "usage-bar limit-hit";
      usageBar.innerHTML = `
      <a href="#" id="upgrade-cta" class="btn btn-primary btn-upgrade">Upgrade to Pro</a>`;
      usageBar.querySelector("#upgrade-cta")?.addEventListener("click", (e) => {
        e.preventDefault();
        chrome.tabs.create({ url: `${SITE_URL}/#pricing` });
      });
    } else {
      haikuBtn.disabled = false;
      usageBar.className = "usage-bar";
      usageBar.innerHTML = `${used} of ${limit} free decodes used today · <a href="#" id="upgrade-link">Upgrade</a>`;
      usageBar.querySelector("#upgrade-link")?.addEventListener("click", (e) => {
        e.preventDefault();
        chrome.tabs.create({ url: `${SITE_URL}/#pricing` });
      });
    }
  };
  var loadUserPlan = async () => {
    const apiKey = await getApiKey();
    if (!apiKey)
      return;
    try {
      const response = await api.usage();
      if ("data" in response) {
        const { plan, used, limit, sonnetUsed, sonnetLimit } = response.data;
        if (plan === "pro") {
          sonnetBtn.classList.remove("hidden");
          const remaining = sonnetLimit - sonnetUsed;
          sonnetRemaining.textContent = `(${remaining} left)`;
        }
        updateUsageDisplay(used, limit, plan);
        chrome.storage.local.set({ userPlan: plan });
      }
    } catch {}
  };
  var isDecoding = false;
  var haikuBtn = document.getElementById("decode-haiku");
  var setDecoding = (loading, phase) => {
    isDecoding = loading;
    haikuBtn.disabled = loading;
    sonnetBtn.disabled = loading;
    const textNode = haikuBtn.firstChild;
    if (loading) {
      haikuRemaining.classList.add("hidden");
      if (textNode)
        textNode.textContent = phase || "Decoding...";
    } else {
      haikuRemaining.classList.remove("hidden");
      if (textNode)
        textNode.textContent = "Decode (Haiku) ";
    }
    decodeInput.readOnly = loading;
  };
  var resolveSourceMaps = async (errorText) => {
    if (!currentTabId)
      return errorText;
    try {
      return new Promise((resolve) => {
        const timer = setTimeout(() => resolve(errorText), 5000);
        chrome.tabs.sendMessage(currentTabId, { type: "RESOLVE_SOURCEMAP", errorText }, (response) => {
          clearTimeout(timer);
          resolve(response?.resolved || errorText);
        });
      });
    } catch {
      return errorText;
    }
  };
  haikuBtn.addEventListener("click", () => {
    const text = decodeInput.value.trim();
    if (!text || isDecoding)
      return;
    decodeSingle(text, "haiku");
  });
  sonnetBtn.addEventListener("click", () => {
    const text = decodeInput.value.trim();
    if (!text || isDecoding)
      return;
    decodeSingle(text, "sonnet");
  });
  var decodeSingle = async (errorText, model) => {
    if (isDecoding)
      return;
    const apiKey = await getApiKey();
    if (!apiKey) {
      decodeResult.innerHTML = `
    <div class="auth-prompt">
      <p>Sign up to start decoding errors</p>
      <p class="auth-sub">Free account — 3 decodes per day</p>
      <button class="btn btn-primary auth-signup-btn">Sign Up Free</button>
      <p class="auth-fallback">Already have a key? <a href="#" class="auth-settings-link">Paste it in Settings</a></p>
    </div>`;
      decodeResult.querySelector(".auth-signup-btn")?.addEventListener("click", () => {
        chrome.tabs.create({ url: AUTH_URL });
      });
      decodeResult.querySelector(".auth-settings-link")?.addEventListener("click", (e) => {
        e.preventDefault();
        chrome.runtime.openOptionsPage();
      });
      return;
    }
    const sensitiveMatches = checkSensitiveData(errorText);
    if (sensitiveMatches.length > 0) {
      const proceed = await showConfirmModal({
        title: "Sensitive Data Detected",
        message: formatSensitiveWarning(sensitiveMatches),
        confirmText: "Send Anyway",
        cancelText: "Go Back & Edit",
        confirmDanger: true
      });
      if (!proceed)
        return;
    }
    setDecoding(true, "Resolving source maps...");
    decodeInput.classList.remove("has-results");
    decodeResult.innerHTML = "";
    const enrichedText = await resolveSourceMaps(errorText);
    setDecoding(true, "Decoding...");
    decodeResult.innerHTML = `<div class="skeleton"></div><div class="skeleton short"></div><div class="skeleton"></div>`;
    try {
      const response = await fetch(`${API_BASE}/decode`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
        body: JSON.stringify({ errorText: enrichedText + getTechContext(), model })
      });
      const json = await response.json();
      if (json.error) {
        if (response.status === 401) {
          decodeResult.innerHTML = `
          <div class="auth-prompt">
            <p>Your API key is invalid or expired.</p>
            <p class="auth-sub">Sign in again or paste a new key in Settings.</p>
            <button class="btn btn-primary auth-signup-btn">Sign In</button>
            <p class="auth-fallback"><a href="#" class="auth-settings-link">Open Settings</a></p>
          </div>`;
          decodeResult.querySelector(".auth-signup-btn")?.addEventListener("click", () => {
            chrome.tabs.create({ url: AUTH_URL });
          });
          decodeResult.querySelector(".auth-settings-link")?.addEventListener("click", (e) => {
            e.preventDefault();
            chrome.runtime.openOptionsPage();
          });
          return;
        }
        if (json.upgradeUrl) {
          decodeResult.innerHTML = `
          <div class="auth-prompt">
            <p>${escapeHtml(json.error.message)}</p>
            <a href="#" class="btn btn-primary btn-upgrade" id="upgrade-429">Upgrade to Pro</a>
          </div>`;
          decodeResult.querySelector("#upgrade-429")?.addEventListener("click", (e) => {
            e.preventDefault();
            chrome.tabs.create({ url: `${SITE_URL}/#pricing` });
          });
        } else {
          decodeResult.innerHTML = `<p class="error-msg">${escapeHtml(json.error.message)}</p>`;
        }
        return;
      }
      renderMarkdown(json.data.markdown, decodeResult);
      decodeInput.classList.add("has-results");
    } catch {
      decodeResult.innerHTML = `<p class="error-msg">Failed to connect to API.</p>`;
    } finally {
      setDecoding(false);
      loadUserPlan();
    }
  };
  var inspectBtn = document.getElementById("inspect-btn");
  var inspectCancelBtn = document.getElementById("inspect-cancel");
  var startInspect = () => {
    if (!currentTabId)
      return;
    chrome.tabs.sendMessage(currentTabId, { type: "START_INSPECT" });
    inspectBtn.textContent = "\uD83D\uDD0D Click an element...";
    inspectBtn.disabled = true;
    inspectCancelBtn.classList.remove("hidden");
  };
  var cancelInspect = () => {
    if (currentTabId) {
      chrome.tabs.sendMessage(currentTabId, { type: "STOP_INSPECT" });
    }
    inspectBtn.textContent = "\uD83D\uDD0D Click to inspect an element";
    inspectBtn.disabled = false;
    inspectCancelBtn.classList.add("hidden");
  };
  inspectBtn.addEventListener("click", startInspect);
  inspectCancelBtn.addEventListener("click", cancelInspect);
  document.getElementById("inspect-new").addEventListener("click", () => {
    document.getElementById("inspect-selected").classList.add("hidden");
    document.getElementById("inspect-start").classList.remove("hidden");
    document.getElementById("inspect-result").innerHTML = "";
    chrome.storage.session.remove("selectedElement");
    startInspect();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !inspectCancelBtn.classList.contains("hidden")) {
      cancelInspect();
    }
  });
  var showInspectResult = (el) => {
    document.getElementById("inspect-start").classList.add("hidden");
    document.getElementById("inspect-selected").classList.remove("hidden");
    inspectBtn.textContent = "\uD83D\uDD0D Click to inspect an element";
    inspectBtn.disabled = false;
    inspectCancelBtn.classList.add("hidden");
    let info = `<${el.tag}`;
    if (el.id)
      info += ` id="${el.id}"`;
    if (el.classes?.length)
      info += ` class="${el.classes.join(" ")}"`;
    info += `>
`;
    info += `Size: ${el.dimensions?.width}×${el.dimensions?.height}px
`;
    const styles = Object.entries(el.styles || {}).slice(0, 10);
    if (styles.length) {
      info += `
Computed styles:
`;
      for (const [prop, val] of styles)
        info += `  ${prop}: ${val}
`;
    }
    if (el.cssRules?.length) {
      info += `
CSS rules:
`;
      for (const rule of el.cssRules.slice(-5)) {
        const source = rule.originalFile ? `→ ${rule.originalFile}` : rule.file;
        info += `  ${rule.selector} (${source})
`;
      }
    }
    document.getElementById("element-info").textContent = info;
    document.getElementById("inspect-result").innerHTML = "";
    const hasResolvedFiles = el.cssRules?.some((r) => r.originalFile);
    const allInline = el.cssRules?.every((r) => r.file === "inline");
    const tipEl = document.getElementById("sourcemap-tip");
    if (tipEl) {
      chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
        const pageUrl = tab?.url || "";
        const isLocal = pageUrl.includes("localhost") || pageUrl.includes("127.0.0.1");
        if (!isLocal && !hasResolvedFiles && !allInline) {
          tipEl.classList.remove("hidden");
        } else {
          tipEl.classList.add("hidden");
        }
      });
    }
  };
  var inspectAskBtn = document.getElementById("inspect-ask-btn");
  inspectAskBtn.addEventListener("click", async () => {
    const question = document.getElementById("inspect-question").value.trim();
    if (!question || inspectAskBtn.disabled)
      return;
    inspectAskBtn.disabled = true;
    inspectAskBtn.textContent = "Thinking...";
    const { selectedElement } = await chrome.storage.session.get("selectedElement");
    if (!selectedElement)
      return;
    const cssRulesText = (selectedElement.cssRules || []).map((r) => {
      const source = r.originalFile ? `${r.originalFile} (bundled in ${r.file})` : r.file;
      return `  ${r.selector} → ${source}: ${r.properties}`;
    }).join(`
`);
    const prompt = `User asks: "${question}"

Element: <${selectedElement.tag}${selectedElement.id ? ` id="${selectedElement.id}"` : ""}${selectedElement.classes?.length ? ` class="${selectedElement.classes.join(" ")}"` : ""}>
Text: "${selectedElement.text}"
Size: ${selectedElement.dimensions?.width}×${selectedElement.dimensions?.height}px
Parent: <${selectedElement.parentTag}>

Computed styles:
${Object.entries(selectedElement.styles || {}).map(([k2, v2]) => `  ${k2}: ${v2}`).join(`
`)}
${cssRulesText ? `
CSS rules applying to this element (selector → file):
${cssRulesText}` : ""}

HTML (truncated):
${selectedElement.outerHTML}${getTechContext()}`;
    const inspectSensitive = checkSensitiveData(prompt);
    if (inspectSensitive.length > 0) {
      const proceed = await showConfirmModal({
        title: "Sensitive Data Detected",
        message: formatSensitiveWarning(inspectSensitive),
        confirmText: "Send Anyway",
        cancelText: "Cancel",
        confirmDanger: true
      });
      if (!proceed) {
        inspectAskBtn.disabled = false;
        inspectAskBtn.textContent = "Ask";
        return;
      }
    }
    const inspectResult = document.getElementById("inspect-result");
    inspectResult.innerHTML = `<div class="skeleton"></div><div class="skeleton short"></div>`;
    const apiKey = await getApiKey();
    if (!apiKey) {
      inspectResult.innerHTML = `
    <div class="auth-prompt">
      <p>Sign up to ask about elements</p>
      <p class="auth-sub">Free account — 3 decodes per day</p>
      <button class="btn btn-primary auth-signup-btn">Sign Up Free</button>
      <p class="auth-fallback">Already have a key? <a href="#" class="auth-settings-link">Paste it in Settings</a></p>
    </div>`;
      inspectResult.querySelector(".auth-signup-btn")?.addEventListener("click", () => {
        chrome.tabs.create({ url: AUTH_URL });
      });
      inspectResult.querySelector(".auth-settings-link")?.addEventListener("click", (e) => {
        e.preventDefault();
        chrome.runtime.openOptionsPage();
      });
      inspectAskBtn.disabled = false;
      inspectAskBtn.textContent = "Ask";
      return;
    }
    try {
      const response = await fetch(`${API_BASE}/decode`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
        body: JSON.stringify({ errorText: prompt, mode: "inspect" })
      });
      const json = await response.json();
      if (json.error) {
        inspectResult.innerHTML = `<p class="error-msg">${escapeHtml(json.error.message)}</p>`;
        return;
      }
      renderMarkdown(json.data.markdown, inspectResult);
    } catch {
      inspectResult.innerHTML = `<p class="error-msg">Failed to connect to API.</p>`;
    } finally {
      inspectAskBtn.disabled = false;
      inspectAskBtn.textContent = "Ask";
    }
  });
  document.getElementById("inspect-question").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      document.getElementById("inspect-ask-btn").click();
    }
  });
  var renderMarkdown = (markdown, container) => {
    container.innerHTML = g.parse(markdown);
    container.querySelectorAll("pre").forEach((pre) => {
      const wrapper = document.createElement("div");
      wrapper.className = "code-block";
      pre.parentNode?.insertBefore(wrapper, pre);
      wrapper.appendChild(pre);
      const btn = document.createElement("button");
      btn.className = "copy-btn";
      btn.textContent = "Copy";
      btn.addEventListener("click", () => copyToClipboard(btn, () => pre.textContent || ""));
      wrapper.appendChild(btn);
    });
  };
  document.getElementById("close-panel").addEventListener("click", () => {
    window.parent.postMessage({ type: "ERRORDECODER_CLOSE" }, "*");
  });
  document.getElementById("settings-link").addEventListener("click", (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });
})();

//# debugId=EF095AB9D797949A64756E2164756E21
