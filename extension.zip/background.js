(() => {
  // packages/extension/src/background/index.ts
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "decode-error",
      title: "Decode this error",
      contexts: ["selection"]
    });
  });
  chrome.action.onClicked.addListener(async (tab) => {
    if (!tab.id)
      return;
    chrome.tabs.sendMessage(tab.id, { type: "TOGGLE_PANEL" });
  });
  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId !== "decode-error" || !info.selectionText || !tab?.id)
      return;
    await chrome.storage.session.set({
      pendingText: info.selectionText
    });
    chrome.tabs.sendMessage(tab.id, { type: "SHOW_PANEL" });
  });
  chrome.webRequest.onCompleted.addListener((details) => {
    if (details.statusCode >= 400 && details.tabId > 0) {
      if (details.url.includes("/api/decode") || details.url.includes("/api/usage"))
        return;
      appendCapturedError({
        text: `Network ${details.statusCode}: ${details.method} ${details.url}`,
        level: "error",
        timestamp: details.timeStamp,
        url: details.url,
        domain: (() => {
          try {
            return new URL(details.url).hostname;
          } catch {
            return "";
          }
        })(),
        source: "network",
        tabId: details.tabId
      });
    }
  }, { urls: ["<all_urls>"] });
  chrome.webRequest.onErrorOccurred.addListener((details) => {
    if (details.url.startsWith("chrome-extension://") || details.tabId < 0)
      return;
    appendCapturedError({
      text: `Network Error: ${details.error} — ${details.method} ${details.url}`,
      level: "error",
      timestamp: details.timeStamp,
      url: details.url,
      domain: (() => {
        try {
          return new URL(details.url).hostname;
        } catch {
          return "";
        }
      })(),
      source: "network",
      tabId: details.tabId
    });
  }, { urls: ["<all_urls>"] });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "CAPTURED_ERROR") {
      appendCapturedError({
        text: message.text,
        level: message.level,
        timestamp: message.timestamp || Date.now(),
        url: message.url,
        domain: message.domain,
        source: "console",
        tabId: sender.tab?.id ?? -1
      });
      sendResponse({ received: true });
    }
    if (message.type === "TECH_DETECTED" && sender.tab?.id) {
      chrome.storage.session.set({ [`tech_tab_${sender.tab.id}`]: message.tech });
      sendResponse({ received: true });
    }
    if (message.type === "ELEMENT_SELECTED") {
      chrome.storage.session.set({ selectedElement: message.element });
      sendResponse({ received: true });
    }
    if (message.type === "INSPECT_CANCELLED") {
      chrome.storage.session.remove("selectedElement");
      sendResponse({ received: true });
    }
    if (message.type === "AUTH_SUCCESS") {
      chrome.storage.local.set({
        apiKey: message.apiKey,
        userEmail: message.email,
        userPlan: message.plan
      });
      sendResponse({ received: true });
    }
    return true;
  });
  chrome.runtime.onMessageExternal.addListener((message, _sender, sendResponse) => {
    if (message.type === "AUTH_SUCCESS") {
      chrome.storage.local.set({
        apiKey: message.apiKey,
        userEmail: message.email,
        userPlan: message.plan
      });
      sendResponse({ received: true });
    } else if (message.type === "PLAN_UPGRADED") {
      chrome.storage.local.set({ userPlan: message.plan });
      sendResponse({ received: true });
    } else if (message.type === "PLAN_CHANGED") {
      chrome.storage.local.set({ planRefreshAt: Date.now() });
      sendResponse({ received: true });
    } else if (message.type === "LOGOUT") {
      chrome.storage.local.remove(["apiKey", "userEmail", "userPlan"]);
      sendResponse({ received: true });
    }
    return true;
  });
  var errorBuffers = new Map;
  var flushTimers = new Map;
  var flushToStorage = (tabId) => {
    const errors = errorBuffers.get(tabId);
    if (!errors)
      return;
    chrome.storage.session.set({ [`errors_tab_${tabId}`]: errors });
    flushTimers.delete(tabId);
  };
  var scheduleFlush = (tabId) => {
    if (flushTimers.has(tabId))
      clearTimeout(flushTimers.get(tabId));
    flushTimers.set(tabId, setTimeout(() => flushToStorage(tabId), 100));
  };
  var appendCapturedError = (error) => {
    const { tabId } = error;
    if (!errorBuffers.has(tabId))
      errorBuffers.set(tabId, []);
    const errors = errorBuffers.get(tabId);
    const last = errors[errors.length - 1];
    if (last && last.text === error.text && error.timestamp - last.timestamp < 500)
      return;
    errors.push(error);
    if (errors.length > 50)
      errors.shift();
    scheduleFlush(tabId);
  };
  chrome.storage.session.onChanged.addListener((changes) => {
    for (const [key, change] of Object.entries(changes)) {
      if (key.startsWith("errors_tab_") && Array.isArray(change.newValue) && change.newValue.length === 0) {
        const tabId = parseInt(key.replace("errors_tab_", ""), 10);
        errorBuffers.set(tabId, []);
      }
    }
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    if (flushTimers.has(tabId)) {
      clearTimeout(flushTimers.get(tabId));
      flushTimers.delete(tabId);
    }
    errorBuffers.delete(tabId);
    chrome.storage.session.remove(`errors_tab_${tabId}`);
  });
})();

//# debugId=F35957DDDCE9C6BE64756E2164756E21
