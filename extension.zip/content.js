(() => {
  // packages/extension/src/content/panel.ts
  var panelFrame = null;
  var dragHandle = null;
  var panelVisible = false;
  var panelWidth = 400;
  var STORAGE_KEY = "errordecoder-panel-width";
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved)
      panelWidth = Math.max(280, Math.min(800, parseInt(saved, 10)));
  } catch {}
  var showPanel = () => {
    if (!panelFrame) {
      createPanel();
    }
    panelFrame.style.transform = "translateX(0)";
    panelFrame.style.width = `${panelWidth}px`;
    dragHandle.style.right = `${panelWidth - 6}px`;
    dragHandle.style.opacity = "1";
    panelVisible = true;
    const html = document.documentElement;
    html.style.transition = "margin-right 0.2s ease";
    html.style.marginRight = `${panelWidth}px`;
    html.style.overflow = "auto";
  };
  var hidePanel = () => {
    if (!panelFrame)
      return;
    panelFrame.style.transform = `translateX(${panelWidth}px)`;
    panelVisible = false;
    if (dragHandle)
      dragHandle.style.opacity = "0";
    const html = document.documentElement;
    html.style.marginRight = "0";
  };
  var isPanelVisible = () => panelVisible;
  var resizePanel = (newWidth) => {
    panelWidth = Math.max(280, Math.min(800, newWidth));
    if (panelFrame) {
      panelFrame.style.width = `${panelWidth}px`;
    }
    if (dragHandle) {
      dragHandle.style.right = `${panelWidth - 6}px`;
    }
    document.documentElement.style.marginRight = `${panelWidth}px`;
    try {
      localStorage.setItem(STORAGE_KEY, String(panelWidth));
    } catch {}
  };
  var createPanel = () => {
    panelFrame = document.createElement("iframe");
    panelFrame.id = "errordecoder-panel";
    panelFrame.src = chrome.runtime.getURL("sidepanel/index.html");
    panelFrame.setAttribute("allow", "clipboard-write");
    Object.assign(panelFrame.style, {
      position: "fixed",
      top: "0",
      right: "0",
      width: `${panelWidth}px`,
      height: "100vh",
      border: "none",
      borderLeft: "1px solid #3e3e3e",
      zIndex: "2147483647",
      transform: `translateX(${panelWidth}px)`,
      transition: "transform 0.2s ease",
      boxShadow: "-2px 0 12px rgba(0, 0, 0, 0.3)",
      backgroundColor: "#1e1e1e"
    });
    document.body.appendChild(panelFrame);
    dragHandle = document.createElement("div");
    dragHandle.id = "errordecoder-drag";
    Object.assign(dragHandle.style, {
      position: "fixed",
      top: "0",
      right: `${panelWidth - 6}px`,
      width: "12px",
      height: "100vh",
      cursor: "col-resize",
      zIndex: "2147483647",
      opacity: "0",
      background: "transparent",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    });
    const grip = document.createElement("div");
    Object.assign(grip.style, {
      width: "4px",
      height: "48px",
      borderRadius: "2px",
      background: "rgba(180, 180, 180, 0.8)",
      transition: "background 0.15s, height 0.15s, width 0.15s"
    });
    dragHandle.appendChild(grip);
    dragHandle.addEventListener("mouseenter", () => {
      grip.style.background = "rgba(86, 156, 214, 0.9)";
      grip.style.height = "64px";
      grip.style.width = "5px";
    });
    dragHandle.addEventListener("mouseleave", () => {
      if (!isDragging) {
        grip.style.background = "rgba(180, 180, 180, 0.8)";
        grip.style.height = "48px";
        grip.style.width = "4px";
      }
    });
    let isDragging = false;
    let startX = 0;
    let startWidth = 0;
    dragHandle.addEventListener("mousedown", (e) => {
      isDragging = true;
      startX = e.clientX;
      startWidth = panelWidth;
      if (panelFrame)
        panelFrame.style.transition = "none";
      document.documentElement.style.transition = "none";
      if (panelFrame)
        panelFrame.style.pointerEvents = "none";
      grip.style.background = "rgba(86, 156, 214, 0.9)";
      grip.style.height = "64px";
      e.preventDefault();
    });
    document.addEventListener("mousemove", (e) => {
      if (!isDragging)
        return;
      const delta = startX - e.clientX;
      resizePanel(startWidth + delta);
    });
    document.addEventListener("mouseup", () => {
      if (!isDragging)
        return;
      isDragging = false;
      if (panelFrame) {
        panelFrame.style.transition = "transform 0.2s ease";
        panelFrame.style.pointerEvents = "auto";
      }
      document.documentElement.style.transition = "margin-right 0.2s ease";
      grip.style.background = "rgba(180, 180, 180, 0.8)";
      grip.style.height = "48px";
      grip.style.width = "4px";
    });
    document.body.appendChild(dragHandle);
    window.addEventListener("message", (event) => {
      if (event.data?.type === "ERRORDECODER_CLOSE") {
        hidePanel();
      }
    });
  };

  // packages/extension/src/content/inspector.ts
  var isInspecting = false;
  var overlay = null;
  var hoveredElement = null;
  var rafId = null;
  var OVERLAY_COLOR = "rgba(86, 156, 214, 0.2)";
  var OVERLAY_BORDER = "rgba(86, 156, 214, 0.8)";
  var startInspecting = () => {
    if (isInspecting)
      return;
    isInspecting = true;
    overlay = document.createElement("div");
    overlay.id = "errordecoder-inspector-overlay";
    Object.assign(overlay.style, {
      position: "fixed",
      pointerEvents: "none",
      zIndex: "2147483646",
      background: OVERLAY_COLOR,
      border: `2px solid ${OVERLAY_BORDER}`,
      borderRadius: "2px",
      transition: "all 0.1s ease",
      display: "none"
    });
    document.body.appendChild(overlay);
    document.addEventListener("mousemove", onMouseMove, true);
    document.addEventListener("click", onClick, true);
    document.addEventListener("keydown", onKeyDown, true);
    document.body.style.cursor = "crosshair";
  };
  var stopInspecting = () => {
    if (!isInspecting)
      return;
    isInspecting = false;
    if (rafId !== null) {
      cancelAnimationFrame(rafId);
      rafId = null;
    }
    overlay?.remove();
    overlay = null;
    hoveredElement = null;
    document.removeEventListener("mousemove", onMouseMove, true);
    document.removeEventListener("click", onClick, true);
    document.removeEventListener("keydown", onKeyDown, true);
    document.body.style.cursor = "";
  };
  var onMouseMove = (e) => {
    let target = e.target;
    if (!(target instanceof HTMLElement))
      target = target.parentElement;
    if (!target || !(target instanceof HTMLElement))
      return;
    if (target.closest("#errordecoder-panel") || target.id === "errordecoder-inspector-overlay")
      return;
    hoveredElement = target;
    if (rafId !== null)
      cancelAnimationFrame(rafId);
    rafId = requestAnimationFrame(() => {
      if (!overlay || !hoveredElement)
        return;
      const rect = hoveredElement.getBoundingClientRect();
      Object.assign(overlay.style, {
        display: "block",
        top: `${rect.top}px`,
        left: `${rect.left}px`,
        width: `${rect.width}px`,
        height: `${rect.height}px`
      });
      rafId = null;
    });
  };
  var onClick = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    let target = hoveredElement;
    if (!target) {
      let node = e.target;
      while (node && !(node instanceof HTMLElement))
        node = node.parentNode;
      target = node;
    }
    if (!target || !(target instanceof HTMLElement))
      return;
    stopInspecting();
    const info = getElementInfo(target);
    chrome.runtime.sendMessage({
      type: "ELEMENT_SELECTED",
      element: info
    }).catch(() => {});
    try {
      const timeout = new Promise((resolve) => setTimeout(() => resolve(null), 3000));
      const resolution = resolveCSSSourceMaps(info.cssRules);
      const resolvedRules = await Promise.race([resolution, timeout]);
      if (resolvedRules && resolvedRules !== info.cssRules) {
        chrome.runtime.sendMessage({
          type: "ELEMENT_SELECTED",
          element: { ...info, cssRules: resolvedRules }
        }).catch(() => {});
      }
    } catch {}
  };
  var onKeyDown = (e) => {
    if (e.key === "Escape") {
      stopInspecting();
      chrome.runtime.sendMessage({ type: "INSPECT_CANCELLED" }).catch(() => {});
    }
  };
  var getElementInfo = (el) => {
    if (!(el instanceof Element))
      return { tag: "unknown", selector: "unknown", styles: {}, dimensions: { width: 0, height: 0, top: 0, left: 0 }, outerHTML: "", childCount: 0, cssRules: [] };
    const computed = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    let selector = el.tagName.toLowerCase();
    if (el.id)
      selector += `#${el.id}`;
    if (el.className && typeof el.className === "string") {
      selector += "." + el.className.trim().split(/\s+/).slice(0, 3).join(".");
    }
    const styles = {};
    const relevantProps = [
      "display",
      "position",
      "width",
      "height",
      "margin",
      "padding",
      "color",
      "background-color",
      "font-size",
      "font-weight",
      "font-family",
      "border",
      "border-radius",
      "flex-direction",
      "justify-content",
      "align-items",
      "gap",
      "grid-template-columns",
      "overflow",
      "opacity",
      "z-index",
      "box-shadow",
      "text-align"
    ];
    for (const prop of relevantProps) {
      const val = computed.getPropertyValue(prop);
      if (val && val !== "none" && val !== "normal" && val !== "auto" && val !== "0px") {
        styles[prop] = val;
      }
    }
    const matchedRules = getMatchedCSSRules(el);
    return {
      tag: el.tagName.toLowerCase(),
      selector,
      id: el.id || undefined,
      classes: el.className && typeof el.className === "string" ? el.className.trim().split(/\s+/) : [],
      text: (el.textContent || "").trim().slice(0, 100),
      attributes: getRelevantAttributes(el),
      styles,
      cssRules: matchedRules,
      dimensions: {
        width: Math.round(rect.width),
        height: Math.round(rect.height),
        top: Math.round(rect.top),
        left: Math.round(rect.left)
      },
      outerHTML: el.outerHTML.slice(0, 500),
      parentTag: el.parentElement?.tagName.toLowerCase(),
      childCount: el.children.length
    };
  };
  var getMatchedCSSRules = (el) => {
    const matched = [];
    try {
      let ruleCount = 0;
      for (const sheet of document.styleSheets) {
        let rules;
        try {
          rules = sheet.cssRules || sheet.rules;
        } catch {
          continue;
        }
        const sheetFile = sheet.href ? sheet.href.split("/").pop()?.split("?")[0] || "inline" : "inline";
        for (const rule of rules) {
          if (ruleCount++ > 500)
            break;
          if (rule instanceof CSSStyleRule) {
            try {
              if (el.matches(rule.selectorText)) {
                const props = [];
                for (let i = 0;i < rule.style.length && i < 20; i++) {
                  const prop = rule.style[i];
                  props.push(`${prop}: ${rule.style.getPropertyValue(prop)}`);
                }
                matched.push({
                  selector: rule.selectorText,
                  file: sheetFile,
                  properties: props.join("; ")
                });
              }
            } catch {}
          }
        }
        if (ruleCount > 500)
          break;
      }
    } catch {}
    return matched.slice(-10);
  };
  var getRelevantAttributes = (el) => {
    const attrs = {};
    const skip = ["class", "id", "style"];
    for (const attr of el.attributes) {
      if (!skip.includes(attr.name)) {
        attrs[attr.name] = attr.value.slice(0, 100);
      }
    }
    return attrs;
  };
  var cssMapCache = new Map;
  var resolveCSSSourceMaps = async (rules) => {
    const sheetUrls = new Set;
    for (const rule of rules) {
      if (rule.file !== "inline" && rule.file.match(/[a-f0-9]{5,}\.(css)/)) {
        sheetUrls.add(rule.file);
      }
    }
    const sourceFilesBySheet = new Map;
    for (const sheetFile of sheetUrls) {
      try {
        const sources = await getCSSSourceFiles(sheetFile);
        if (sources.length > 0) {
          sourceFilesBySheet.set(sheetFile, sources);
        }
      } catch {}
    }
    return rules.map((rule) => {
      if (rule.file === "inline" || !sourceFilesBySheet.has(rule.file)) {
        return rule;
      }
      const originalFile = findSelectorInSources(rule.selector, rule.file);
      return { ...rule, originalFile: originalFile || undefined };
    });
  };
  var getCSSSourceFiles = async (cssFilename) => {
    if (cssMapCache.has(cssFilename)) {
      const cached = cssMapCache.get(cssFilename);
      return cached?.sources || [];
    }
    try {
      let cssUrl = "";
      for (const sheet of document.styleSheets) {
        if (sheet.href?.includes(cssFilename)) {
          cssUrl = sheet.href;
          break;
        }
      }
      if (!cssUrl) {
        cssMapCache.set(cssFilename, null);
        return [];
      }
      let cssText;
      const rangeResponse = await fetch(cssUrl, { headers: { Range: "bytes=-512" } });
      if (rangeResponse.status === 206) {
        cssText = await rangeResponse.text();
      } else if (rangeResponse.status === 200) {
        cssText = await rangeResponse.text();
      } else {
        cssMapCache.set(cssFilename, null);
        return [];
      }
      const urlMatch = cssText.match(/\/\*[#@]\s*sourceMappingURL=(.+?)\s*\*\//);
      if (!urlMatch) {
        cssMapCache.set(cssFilename, null);
        return [];
      }
      let mapUrl = urlMatch[1];
      if (mapUrl.startsWith("data:")) {
        const base64Match = mapUrl.match(/base64,(.+)/);
        if (base64Match) {
          const map2 = JSON.parse(atob(base64Match[1]));
          cssMapCache.set(cssFilename, map2);
          return map2.sources || [];
        }
        cssMapCache.set(cssFilename, null);
        return [];
      }
      if (!mapUrl.startsWith("http")) {
        const base = cssUrl.substring(0, cssUrl.lastIndexOf("/") + 1);
        mapUrl = base + mapUrl;
      }
      const mapResponse = await fetch(mapUrl);
      if (!mapResponse.ok) {
        cssMapCache.set(cssFilename, null);
        return [];
      }
      const map = await mapResponse.json();
      cssMapCache.set(cssFilename, map);
      return map.sources || [];
    } catch {
      cssMapCache.set(cssFilename, null);
      return [];
    }
  };
  var findSelectorInSources = (selector, cssFilename) => {
    const map = cssMapCache.get(cssFilename);
    if (!map?.sourcesContent || !map?.sources)
      return null;
    const searchTerm = selector.replace(/\\/g, "");
    for (let i = 0;i < map.sourcesContent.length; i++) {
      const content = map.sourcesContent[i];
      if (!content)
        continue;
      if (content.includes(searchTerm)) {
        const source = map.sources[i];
        return source.split("/").slice(-2).join("/");
      }
    }
    const appSources = map.sources.filter((s) => !s.includes("node_modules") && (s.endsWith(".vue") || s.endsWith(".tsx") || s.endsWith(".jsx") || s.endsWith(".scss") || s.endsWith(".css"))).map((s) => s.split("/").slice(-2).join("/"));
    return appSources.length > 0 ? `One of: ${appSources.slice(0, 5).join(", ")}` : null;
  };

  // packages/extension/src/content/tech-detect.ts
  var cachedTech = null;
  window.addEventListener("popstate", () => {
    cachedTech = null;
  });
  window.addEventListener("hashchange", () => {
    cachedTech = null;
  });
  var detectTechStack = () => {
    if (cachedTech)
      return cachedTech;
    const detected = [];
    const add = (tech) => {
      if (!detected.some((t) => t.name === tech.name))
        detected.push(tech);
    };
    const globals = getPageGlobals();
    const scriptUrls = getScriptUrls();
    const linkUrls = getLinkUrls();
    const allSrc = scriptUrls + " " + linkUrls;
    if (globals.react || document.querySelector("[data-reactroot]") || document.querySelector("[data-react-helmet]")) {
      add({ name: "React", category: "framework", version: globals.reactVersion || undefined, color: "#61dafb" });
    }
    if (globals.nextjs || document.querySelector("#__next")) {
      add({ name: "Next.js", category: "framework", color: "#000000" });
    }
    if (globals.vue || document.querySelector("[data-v-]") || document.querySelector("[data-vue-app]")) {
      add({ name: "Vue", category: "framework", color: "#42b883" });
    }
    if (globals.nuxt || document.querySelector("#__nuxt")) {
      add({ name: "Nuxt", category: "framework", color: "#00dc82" });
    }
    const ngVer = document.querySelector("[ng-version]")?.getAttribute("ng-version");
    if (globals.angular || ngVer) {
      add({ name: "Angular", category: "framework", version: ngVer || undefined, color: "#dd0031" });
    }
    if (globals.svelte || document.querySelector("[class*='svelte-']")) {
      add({ name: "Svelte", category: "framework", color: "#ff3e00" });
    }
    if (document.querySelector("[data-astro-cid]") || document.querySelector("astro-island")) {
      add({ name: "Astro", category: "framework", color: "#ff5d01" });
    }
    if (globals.remix)
      add({ name: "Remix", category: "framework", color: "#000000" });
    if (globals.solid)
      add({ name: "SolidJS", category: "framework", color: "#2c4f7c" });
    if (document.querySelector("[data-qwik]") || globals.qwik) {
      add({ name: "Qwik", category: "framework", color: "#18b6f6" });
    }
    if (globals.ember || document.querySelector("[id^='ember']")) {
      add({ name: "Ember", category: "framework", color: "#e04e39" });
    }
    if (globals.preact)
      add({ name: "Preact", category: "framework", color: "#673ab8" });
    if (document.querySelector("[x-data]") || document.querySelector("[x-bind]")) {
      add({ name: "Alpine.js", category: "framework", color: "#77c1d2" });
    }
    if (document.querySelector("[hx-get]") || document.querySelector("[hx-post]") || document.querySelector("[data-hx-get]")) {
      add({ name: "HTMX", category: "framework", color: "#3366cc" });
    }
    if (globals.lit || document.querySelector("[lit-element]")) {
      add({ name: "Lit", category: "framework", color: "#324fff" });
    }
    if (document.querySelector('meta[name="csrf-token"]') && document.querySelector('meta[name="csrf-param"]')) {
      add({ name: "Ruby on Rails", category: "framework", color: "#cc0000" });
    }
    if (document.querySelector('meta[name="csrf-token"][content]') && allSrc.includes("laravel") || document.querySelector('input[name="_token"]') && document.cookie.includes("laravel_session")) {
      add({ name: "Laravel", category: "framework", color: "#ff2d20" });
    }
    if (document.querySelector('input[name="csrfmiddlewaretoken"]') || allSrc.includes("django")) {
      add({ name: "Django", category: "framework", color: "#092e20" });
    }
    if (document.querySelector('meta[name="generator"][content*="WordPress"]') || allSrc.includes("wp-content") || allSrc.includes("wp-includes")) {
      add({ name: "WordPress", category: "cms", color: "#21759b" });
    }
    if (document.querySelector('meta[name="generator"][content*="Drupal"]') || allSrc.includes("drupal")) {
      add({ name: "Drupal", category: "cms", color: "#0678be" });
    }
    if (allSrc.includes("cdn.shopify.com") || document.querySelector('meta[name="shopify"]')) {
      add({ name: "Shopify", category: "cms", color: "#96bf48" });
    }
    if (allSrc.includes("squarespace.com")) {
      add({ name: "Squarespace", category: "cms", color: "#000000" });
    }
    if (allSrc.includes("wix.com") || document.querySelector("[data-mesh-id]")) {
      add({ name: "Wix", category: "cms", color: "#0c6efc" });
    }
    if (document.querySelector("#phpmyadmin") || document.title.includes("phpMyAdmin")) {
      add({ name: "phpMyAdmin", category: "database", color: "#f89d13" });
    }
    if (document.title.includes("pgAdmin") || document.querySelector("[data-pgadmin]")) {
      add({ name: "pgAdmin", category: "database", color: "#336791" });
    }
    if (document.title.includes("Adminer") || document.querySelector("#content.adminer")) {
      add({ name: "Adminer", category: "database", color: "#34567c" });
    }
    const hasTailwind = document.querySelector("[class*='flex ']") && document.querySelector("[class*='bg-']") && (document.querySelector("[class*='px-']") || document.querySelector("[class*='py-']"));
    if (hasTailwind)
      add({ name: "Tailwind", category: "ui", color: "#06b6d4" });
    if (document.querySelector(".container.bootstrap") || document.querySelector("[class*='btn-primary']") && document.querySelector("[class*='col-']")) {
      add({ name: "Bootstrap", category: "ui", color: "#7952b3" });
    }
    if (document.querySelector("[class*='MuiButton']") || document.querySelector("[class*='MuiTypography']")) {
      add({ name: "Material UI", category: "ui", color: "#007fff" });
    }
    if (document.querySelector("[class*='chakra-']")) {
      add({ name: "Chakra UI", category: "ui", color: "#319795" });
    }
    if (document.querySelector("[class*='ant-']")) {
      add({ name: "Ant Design", category: "ui", color: "#1890ff" });
    }
    if (document.querySelector("[class*='bulma']") || allSrc.includes("bulma")) {
      add({ name: "Bulma", category: "ui", color: "#00d1b2" });
    }
    if (document.querySelector("[data-radix-collection-item]") || document.querySelector("[data-radix-popper-content-wrapper]")) {
      add({ name: "Radix UI", category: "ui", color: "#111111" });
    }
    if (allSrc.includes("foundation.min") || document.querySelector(".foundation-mq")) {
      add({ name: "Foundation", category: "ui", color: "#1779ba" });
    }
    if (globals.vite || document.querySelector('script[type="module"][src*="/@vite"]') || allSrc.includes("/@vite/")) {
      add({ name: "Vite", category: "build", color: "#646cff" });
    }
    if (globals.webpack)
      add({ name: "Webpack", category: "build", color: "#8dd6f9" });
    if (globals.turbopack)
      add({ name: "Turbopack", category: "build", color: "#f38020" });
    if (allSrc.includes("parcel"))
      add({ name: "Parcel", category: "build", color: "#e6a317" });
    if (globals.redux)
      add({ name: "Redux", category: "state", color: "#764abc" });
    if (globals.zustand)
      add({ name: "Zustand", category: "state", color: "#443e38" });
    if (globals.mobx)
      add({ name: "MobX", category: "state", color: "#ff9955" });
    if (globals.pinia)
      add({ name: "Pinia", category: "state", color: "#ffd859" });
    if (globals.jquery) {
      add({ name: "jQuery", category: "runtime", version: globals.jqueryVersion || undefined, color: "#0769ad" });
    }
    if (globals.lodash)
      add({ name: "Lodash", category: "runtime", version: globals.lodash || undefined, color: "#3492ff" });
    if (globals.axios)
      add({ name: "Axios", category: "runtime", color: "#5a29e4" });
    if (allSrc.includes("socket.io"))
      add({ name: "Socket.IO", category: "runtime", color: "#010101" });
    if (allSrc.includes("apollo") || globals.apollo)
      add({ name: "Apollo GraphQL", category: "runtime", color: "#311c87" });
    if (allSrc.includes("three.js") || allSrc.includes("three.min"))
      add({ name: "Three.js", category: "runtime", color: "#000000" });
    if (allSrc.includes("d3.min") || allSrc.includes("d3.v"))
      add({ name: "D3.js", category: "runtime", color: "#f9a03c" });
    if (allSrc.includes("chart.js") || globals.chart)
      add({ name: "Chart.js", category: "runtime", color: "#ff6384" });
    if (allSrc.includes("moment.min") || allSrc.includes("moment.js"))
      add({ name: "Moment.js", category: "runtime", color: "#4a4a55" });
    if (allSrc.includes("gsap") || globals.gsap)
      add({ name: "GSAP", category: "runtime", color: "#88ce02" });
    if (allSrc.includes("anime.min"))
      add({ name: "Anime.js", category: "runtime", color: "#f74f82" });
    if (document.querySelector('script[src*=".tsx"]') || document.querySelector('script[src*=".ts"]')) {
      add({ name: "TypeScript", category: "runtime", color: "#3178c6" });
    }
    if (allSrc.includes("google-analytics") || allSrc.includes("gtag") || allSrc.includes("googletagmanager")) {
      add({ name: "Google Analytics", category: "analytics", color: "#e37400" });
    }
    if (allSrc.includes("mixpanel"))
      add({ name: "Mixpanel", category: "analytics", color: "#7856ff" });
    if (allSrc.includes("facebook.net") || allSrc.includes("fbevents")) {
      add({ name: "Facebook Pixel", category: "analytics", color: "#1877f2" });
    }
    if (allSrc.includes("hotjar"))
      add({ name: "Hotjar", category: "analytics", color: "#fd3a5c" });
    if (allSrc.includes("clarity.ms"))
      add({ name: "Clarity", category: "analytics", color: "#0078d4" });
    if (allSrc.includes("hs-analytics") || allSrc.includes("hsforms") || allSrc.includes("hubspot")) {
      add({ name: "HubSpot", category: "analytics", color: "#ff7a59" });
    }
    if (allSrc.includes("segment.com") || allSrc.includes("segment.io"))
      add({ name: "Segment", category: "analytics", color: "#52bd94" });
    if (allSrc.includes("amplitude"))
      add({ name: "Amplitude", category: "analytics", color: "#1c1c63" });
    if (allSrc.includes("posthog"))
      add({ name: "PostHog", category: "analytics", color: "#f9bd2b" });
    if (allSrc.includes("plausible"))
      add({ name: "Plausible", category: "analytics", color: "#5850ec" });
    if (allSrc.includes("heap-"))
      add({ name: "Heap", category: "analytics", color: "#ff5733" });
    if (allSrc.includes("linkedin.com/insight") || allSrc.includes("snap.licdn")) {
      add({ name: "LinkedIn Insight", category: "analytics", color: "#0a66c2" });
    }
    if (allSrc.includes("tiktok.com/i18n") || allSrc.includes("analytics.tiktok")) {
      add({ name: "TikTok Pixel", category: "analytics", color: "#000000" });
    }
    if (allSrc.includes("twitter.com/oct") || allSrc.includes("static.ads-twitter")) {
      add({ name: "Twitter Pixel", category: "analytics", color: "#1da1f2" });
    }
    if (allSrc.includes("pinterest.com/ct") || allSrc.includes("pintrk")) {
      add({ name: "Pinterest Tag", category: "analytics", color: "#e60023" });
    }
    if (allSrc.includes("stripe.com") || allSrc.includes("js.stripe.com")) {
      add({ name: "Stripe", category: "payment", color: "#635bff" });
    }
    if (allSrc.includes("paypal.com") || allSrc.includes("paypalobjects")) {
      add({ name: "PayPal", category: "payment", color: "#003087" });
    }
    if (allSrc.includes("square.com") || allSrc.includes("squareup.com")) {
      add({ name: "Square", category: "payment", color: "#006aff" });
    }
    if (allSrc.includes("braintree") || allSrc.includes("braintreegateway")) {
      add({ name: "Braintree", category: "payment", color: "#000000" });
    }
    if (allSrc.includes("wingspan.app") || allSrc.includes("wingspan.com")) {
      add({ name: "Wingspan", category: "payment", color: "#1a56db" });
    }
    if (allSrc.includes("adyen.com") || allSrc.includes("adyencheckout")) {
      add({ name: "Adyen", category: "payment", color: "#0abf53" });
    }
    if (allSrc.includes("venmo") || allSrc.includes("venmo.com")) {
      add({ name: "Venmo", category: "payment", color: "#3d95ce" });
    }
    if (allSrc.includes("cash.app") || allSrc.includes("cashapp")) {
      add({ name: "Cash App", category: "payment", color: "#00d632" });
    }
    if (allSrc.includes("coinbase.com") || allSrc.includes("coinbase-commerce")) {
      add({ name: "Coinbase", category: "payment", color: "#0052ff" });
    }
    if (allSrc.includes("commerce.coinbase")) {
      add({ name: "Coinbase Commerce", category: "payment", color: "#0052ff" });
    }
    if (allSrc.includes("metamask") || globals.ethereum) {
      add({ name: "MetaMask/Web3", category: "payment", color: "#f6851b" });
    }
    if (allSrc.includes("solana") || globals.solana) {
      add({ name: "Solana", category: "payment", color: "#9945ff" });
    }
    if (allSrc.includes("ethers.js") || allSrc.includes("ethers.min")) {
      add({ name: "Ethers.js", category: "payment", color: "#2535a0" });
    }
    if (allSrc.includes("web3.min") || allSrc.includes("web3.js") || globals.web3) {
      add({ name: "Web3.js", category: "payment", color: "#f16822" });
    }
    if (allSrc.includes("wagmi") || allSrc.includes("rainbowkit")) {
      add({ name: "RainbowKit", category: "payment", color: "#7b3fe4" });
    }
    if (allSrc.includes("plaid.com") || allSrc.includes("plaid-link")) {
      add({ name: "Plaid", category: "payment", color: "#111111" });
    }
    if (globals.sentry || allSrc.includes("sentry"))
      add({ name: "Sentry", category: "monitoring", color: "#362d59" });
    if (allSrc.includes("datadog"))
      add({ name: "Datadog", category: "monitoring", color: "#632ca6" });
    if (allSrc.includes("newrelic") || allSrc.includes("nr-data"))
      add({ name: "New Relic", category: "monitoring", color: "#008c99" });
    if (allSrc.includes("logrocket"))
      add({ name: "LogRocket", category: "monitoring", color: "#764abc" });
    if (allSrc.includes("fullstory"))
      add({ name: "FullStory", category: "monitoring", color: "#448aff" });
    if (allSrc.includes("bugsnag"))
      add({ name: "Bugsnag", category: "monitoring", color: "#4949e4" });
    if (allSrc.includes("rollbar"))
      add({ name: "Rollbar", category: "monitoring", color: "#1c1c1c" });
    if (allSrc.includes("intercom"))
      add({ name: "Intercom", category: "chat", color: "#1f8ded" });
    if (allSrc.includes("zendesk"))
      add({ name: "Zendesk", category: "chat", color: "#03363d" });
    if (allSrc.includes("drift.com") || document.querySelector("#drift-widget")) {
      add({ name: "Drift", category: "chat", color: "#0176ff" });
    }
    if (allSrc.includes("crisp.chat"))
      add({ name: "Crisp", category: "chat", color: "#1972f5" });
    if (allSrc.includes("livechatinc") || allSrc.includes("livechat")) {
      add({ name: "LiveChat", category: "chat", color: "#ff5100" });
    }
    if (allSrc.includes("tawk.to"))
      add({ name: "Tawk.to", category: "chat", color: "#1dbe72" });
    if (allSrc.includes("freshdesk") || allSrc.includes("freshchat")) {
      add({ name: "Freshdesk", category: "chat", color: "#25c16f" });
    }
    if (allSrc.includes("auth0.com"))
      add({ name: "Auth0", category: "auth", color: "#eb5424" });
    if (allSrc.includes("clerk.com") || allSrc.includes("clerk.dev"))
      add({ name: "Clerk", category: "auth", color: "#6c47ff" });
    if (allSrc.includes("supabase"))
      add({ name: "Supabase", category: "auth", color: "#3ecf8e" });
    if (allSrc.includes("vercel") || document.querySelector('meta[name="next-head-count"]')) {
      add({ name: "Vercel", category: "hosting", color: "#000000" });
    }
    if (allSrc.includes("netlify") || document.querySelector('meta[name="generator"][content*="Netlify"]')) {
      add({ name: "Netlify", category: "hosting", color: "#00c7b7" });
    }
    if (allSrc.includes("cloudflare") || document.querySelector('script[src*="cloudflare"]')) {
      add({ name: "Cloudflare", category: "hosting", color: "#f38020" });
    }
    if (allSrc.includes("firebase") || globals.firebase) {
      add({ name: "Firebase", category: "hosting", color: "#ffca28" });
    }
    if (allSrc.includes("recaptcha") || allSrc.includes("grecaptcha")) {
      add({ name: "reCAPTCHA", category: "auth", color: "#4285f4" });
    }
    if (allSrc.includes("hcaptcha"))
      add({ name: "hCaptcha", category: "auth", color: "#0074bf" });
    if (allSrc.includes("turnstile") || allSrc.includes("challenges.cloudflare")) {
      add({ name: "Turnstile", category: "auth", color: "#f38020" });
    }
    cachedTech = detected;
    return detected;
  };
  var getPageGlobals = () => {
    try {
      const raw = document.documentElement.getAttribute("data-errordecoder-globals");
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  };
  var getScriptUrls = () => {
    return Array.from(document.querySelectorAll("script[src]")).map((s) => s.getAttribute("src") || "").join(" ");
  };
  var getLinkUrls = () => {
    return Array.from(document.querySelectorAll("link[href]")).map((l) => l.getAttribute("href") || "").join(" ");
  };

  // packages/extension/src/content/sourcemap.ts
  var mapCache = new Map;
  var decodedCache = new Map;
  var resolveStackTrace = async (errorText) => {
    const frameRegex = /(?:at\s+.*?\(|at\s+)?(https?:\/\/[^\s:]+|\/[^\s:]+):(\d+):(\d+)/g;
    const frames = [];
    let m;
    while ((m = frameRegex.exec(errorText)) !== null) {
      frames.push({
        match: m[0],
        url: m[1],
        line: parseInt(m[2], 10),
        col: parseInt(m[3], 10)
      });
    }
    if (frames.length === 0)
      return errorText;
    const resolved = [];
    for (const frame of frames.slice(0, 5)) {
      try {
        const result = await resolveFrame(frame.url, frame.line, frame.col);
        resolved.push({ frame, resolved: result });
      } catch {
        resolved.push({ frame, resolved: null });
      }
    }
    let enriched = errorText;
    let sourceSnippets = "";
    for (const { frame, resolved: res } of resolved) {
      if (!res)
        continue;
      enriched += `
  → ${res.original.file}:${res.original.line}:${res.original.column} (resolved from ${frame.url.split("/").pop()})`;
      if (res.source) {
        sourceSnippets += `

Source: ${res.original.file}:${res.original.line}
${res.source}`;
      }
    }
    if (sourceSnippets) {
      enriched += `

--- Resolved Source Code ---` + sourceSnippets;
    }
    return enriched;
  };
  var resolveFrame = async (scriptUrl, line, col) => {
    const map = await fetchSourceMap(scriptUrl);
    if (!map)
      return null;
    let decoded = decodedCache.get(scriptUrl);
    if (!decoded) {
      decoded = decodeMappings(map.mappings);
      decodedCache.set(scriptUrl, decoded);
    }
    const originalPos = findOriginalPosition(decoded, line - 1, col - 1);
    if (!originalPos)
      return null;
    const sourceFile = map.sources[originalPos.sourceIndex] || "unknown";
    const sourceContent = map.sourcesContent?.[originalPos.sourceIndex];
    let sourceSnippet;
    if (sourceContent) {
      sourceSnippet = extractLines(sourceContent, originalPos.line, 3);
    }
    return {
      original: {
        file: sourceFile,
        line: originalPos.line + 1,
        column: originalPos.column
      },
      source: sourceSnippet
    };
  };
  var fetchSourceMap = async (scriptUrl) => {
    if (mapCache.has(scriptUrl))
      return mapCache.get(scriptUrl) || null;
    try {
      let scriptText;
      const rangeResponse = await fetch(scriptUrl, { headers: { Range: "bytes=-512" } });
      if (rangeResponse.status === 206) {
        scriptText = await rangeResponse.text();
      } else if (rangeResponse.status === 200) {
        scriptText = await rangeResponse.text();
      } else {
        mapCache.set(scriptUrl, null);
        return null;
      }
      const urlMatch = scriptText.match(/\/\/[#@]\s*sourceMappingURL=(.+?)(?:\s|$)/);
      if (!urlMatch) {
        mapCache.set(scriptUrl, null);
        return null;
      }
      let mapUrl = urlMatch[1];
      if (mapUrl.startsWith("data:")) {
        const base64Match = mapUrl.match(/base64,(.+)/);
        if (base64Match) {
          const json = atob(base64Match[1]);
          const map2 = JSON.parse(json);
          mapCache.set(scriptUrl, map2);
          return map2;
        }
        mapCache.set(scriptUrl, null);
        return null;
      }
      if (!mapUrl.startsWith("http")) {
        const base = scriptUrl.substring(0, scriptUrl.lastIndexOf("/") + 1);
        mapUrl = base + mapUrl;
      }
      const mapResponse = await fetch(mapUrl);
      if (!mapResponse.ok) {
        mapCache.set(scriptUrl, null);
        return null;
      }
      const map = await mapResponse.json();
      mapCache.set(scriptUrl, map);
      return map;
    } catch {
      mapCache.set(scriptUrl, null);
      return null;
    }
  };
  var extractLines = (source, targetLine, context) => {
    const lines = source.split(`
`);
    const start = Math.max(0, targetLine - context);
    const end = Math.min(lines.length - 1, targetLine + context);
    return lines.slice(start, end + 1).map((line, i) => {
      const lineNum = start + i + 1;
      const marker = lineNum === targetLine + 1 ? "→" : " ";
      return `${marker} ${String(lineNum).padStart(4)} | ${line}`;
    }).join(`
`);
  };
  var VLQ_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var VLQ_LOOKUP = new Uint8Array(128).fill(255);
  for (let i = 0;i < VLQ_CHARS.length; i++) {
    VLQ_LOOKUP[VLQ_CHARS.charCodeAt(i)] = i;
  }
  var decodeVLQ = (encoded) => {
    const values = [];
    let shift = 0;
    let value = 0;
    for (const char of encoded) {
      const digit = VLQ_LOOKUP[char.charCodeAt(0)];
      if (digit === undefined || digit === 255)
        continue;
      const cont = digit & 32;
      value += (digit & 31) << shift;
      if (cont) {
        shift += 5;
      } else {
        const isNegative = value & 1;
        value >>= 1;
        values.push(isNegative ? -value : value);
        value = 0;
        shift = 0;
      }
    }
    return values;
  };
  var decodeMappings = (mappings) => {
    const lines = mappings.split(";");
    const decoded = [];
    let sourceIndex = 0;
    let sourceLine = 0;
    let sourceColumn = 0;
    for (const line of lines) {
      const segments = [];
      let generatedColumn = 0;
      if (line) {
        for (const segment of line.split(",")) {
          const values = decodeVLQ(segment);
          if (values.length >= 4) {
            generatedColumn += values[0];
            sourceIndex += values[1];
            sourceLine += values[2];
            sourceColumn += values[3];
            segments.push({
              generatedColumn,
              sourceIndex,
              line: sourceLine,
              column: sourceColumn
            });
          } else if (values.length >= 1) {
            generatedColumn += values[0];
          }
        }
      }
      decoded.push(segments);
    }
    return decoded;
  };
  var findOriginalPosition = (decoded, line, column) => {
    if (line >= decoded.length)
      return null;
    const segments = decoded[line];
    if (!segments || segments.length === 0)
      return null;
    let best = segments[0];
    for (const seg of segments) {
      if (seg.generatedColumn <= column) {
        best = seg;
      } else {
        break;
      }
    }
    if (!best)
      return null;
    return {
      sourceIndex: best.sourceIndex,
      line: best.line,
      column: best.column
    };
  };

  // packages/extension/src/content/index.ts
  var runTechDetection = () => {
    setTimeout(() => {
      const tech = detectTechStack();
      chrome.runtime.sendMessage({
        type: "TECH_DETECTED",
        tech
      }).catch(() => {});
    }, 1500);
  };
  if (document.readyState === "complete") {
    runTechDetection();
  } else {
    window.addEventListener("load", runTechDetection);
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "RESOLVE_SOURCEMAP") {
      resolveStackTrace(message.errorText).then((resolved) => {
        sendResponse({ resolved });
      }).catch(() => {
        sendResponse({ resolved: message.errorText });
      });
      return true;
    }
    if (message.type === "GET_PAGE_CONTEXT") {
      const tech = detectTechStack();
      sendResponse({
        url: window.location.href,
        domain: window.location.hostname,
        tech,
        isDev: window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1" || window.location.port !== ""
      });
    }
    if (message.type === "SHOW_PANEL") {
      showPanel();
      sendResponse({ shown: true });
    }
    if (message.type === "HIDE_PANEL") {
      hidePanel();
      sendResponse({ hidden: true });
    }
    if (message.type === "TOGGLE_PANEL") {
      if (isPanelVisible())
        hidePanel();
      else
        showPanel();
      sendResponse({ visible: isPanelVisible() });
    }
    if (message.type === "START_INSPECT") {
      startInspecting();
      sendResponse({ started: true });
    }
    if (message.type === "STOP_INSPECT") {
      stopInspecting();
      sendResponse({ stopped: true });
    }
  });
})();

//# debugId=5F639C4080143C2164756E2164756E21
