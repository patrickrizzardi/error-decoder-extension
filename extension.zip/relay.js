(() => {
  // packages/extension/src/content/relay.ts
  document.addEventListener("errordecoder-error", (event) => {
    chrome.runtime.sendMessage({
      type: "CAPTURED_ERROR",
      text: event.detail.text,
      level: event.detail.level,
      timestamp: Date.now(),
      url: window.location.href,
      domain: window.location.hostname
    }).catch(() => {});
  });
})();

//# debugId=9E5E87D6502428B264756E2164756E21
